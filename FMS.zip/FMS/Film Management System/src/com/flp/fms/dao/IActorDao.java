package com.flp.fms.dao;
import java.util.Set;
import com.flp.fms.domain.Actor;

public interface IActorDao {
	// set method for actor
	public Set<Actor> getActors();

}
