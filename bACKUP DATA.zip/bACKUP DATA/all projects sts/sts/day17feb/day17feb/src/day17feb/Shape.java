package day17feb;

public class Shape {

//	public static void main(String[] args) {
		// TODO Auto-generated method stub
int radius;
int base, height;
	
public void draw(){
	System.out.println("Shape Class Draw Method");
}
}
