package com.flp.fms.service;
import java.util.ArrayList;
import java.util.List;

import com.flp.fms.dao.FilmDaoImplForDB;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.LoginUser;

import java.util.Map;
import java.util.Set;
import com.flp.fms.domain.Film;


public class FilmServiceImpl implements IFilmService{
	
	
	private IFilmDao filmDao=new FilmDaoImplForDB();

	// to display language list
	@Override
	public List<Language> getLanguages() {
		
		return filmDao.getLanguages();
	}

	// to display category list
public List<Category> getCategory() {
		
		return filmDao.getCategory();
}
// adding film
@Override
public int addFilm(Film film) {
	
	return filmDao.addFilm(film);
	
}

 // to search the film
	public Map<Integer, Film> searchfilm() {
		
		return filmDao.searchfilm();
	
}
	// remove the film
	@Override
	public Map<Integer, Film> removefilm() {
		// TODO Auto-generated method stub
		return filmDao.removefilm();
	}
   // listing all film in listallservlet
	@Override
	public ArrayList<Film> getAllFilms() {
		// TODO Auto-generated method stub
		return filmDao.getAllFilms();
	}
	// delete film method
    @Override
    public Boolean deleteFilm(int filmid) {
	// TODO Auto-generated method stub
	return filmDao.deleteFilm(filmid);
}
    // search film 
	@Override
	public ArrayList<Film> searchFilm(Film film) {
		// TODO Auto-generated method stub
		return filmDao.searchFilm(film);
		
		}

	// modifying film
	@Override
	public Boolean modifyFilm(Film film) {
		// TODO Auto-generated method stub
		return filmDao.modifyFilm(film);
	}
// for login
	@Override
	public boolean isValidLogin(LoginUser loginUser) {
		
		return filmDao.isValidLogin(loginUser);
	}
	}


