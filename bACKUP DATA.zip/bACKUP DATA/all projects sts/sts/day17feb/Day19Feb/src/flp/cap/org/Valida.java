package flp.cap.org;

public class Valida {
	
	public static boolean isValidKinid(String kinid){
		return kinid.matches("\\d{5}_[F|I|T][S]");
	}
	
	public static boolean isValidfirstname(String firstname){
	return firstname.matches("[A-Z][a-z]+");
	}
    
	public static boolean isValidlastname(String lastname){
		return lastname.matches("[A-Z][a-z]+");
}
	public static boolean isValidaddress(String address){
		return address.matches("[A-Z][a-z]+");
	}
	
	public static boolean isValidemail(String email){
		return email.matches("[a-z]+[@][a-z]+[.][a-z]");
}
	public static boolean isValidmobile(String mobile){
		return mobile.matches("\\d{10}");
	}

	
	}
	

