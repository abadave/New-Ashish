package flp.cap.demo;

public class LeapYear {
	
	public boolean isdivisibleby4(long no){
		if (no%4==0)
		System.out.println("LeapYear");	
		return true;
		
		}
		
	public boolean isdivisibleby100and400(long no)
	{
		if(no%100==0 && no%400==0)
			System.out.println("LeapYear");
		return true;
		
	}
	
	public boolean isdivisibleby100butnotby400(long no)
	{
		if(no%100==0 && (no%400)!=0)
			System.out.println("NotLeapYear");
		return true;
		
	}
	
}
