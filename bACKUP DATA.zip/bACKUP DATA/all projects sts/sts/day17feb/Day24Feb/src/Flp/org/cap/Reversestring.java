package Flp.org.cap;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Reversestring {

	public static void main(String[] args) {
 File file=new File ("D:\\Ashish_Apple\\Ashish.txt");
try {
	FileReader fileReader =new FileReader(file);
	long size= file.length();
	int len=(int)size;
char[] chars= new char [(int)size];
int i=0;
	while (size>0)
	{   chars[i]=(char)fileReader.read();
		System.out.print(chars[i]);
	    size--;
	    i++;
	}
	
	System.out.println();
	for (int j=len-1;j>=0;j--){
		System.out.print(chars[j]);
	}
}catch (FileNotFoundException ex){
ex.printStackTrace();
}
catch (IOException ex){
ex.printStackTrace();
}


	}
}
