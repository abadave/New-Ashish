package com.flp.fms.dao;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.LoginUser;


public interface IFilmDao {
	// method for login
	public boolean isValidLogin(LoginUser loginUser) ;
	
	// method for language adding
	public List<Language> getLanguages();
	
	//method for category adding
    public List <Category> getCategory();

    // method for adding film --> addfilm servlet
    public int addFilm(Film film);

    
    // method for search film
    public Map<Integer, Film> searchfilm();
    
 // method for remove film
    public Map<Integer, Film> removefilm();
    
	//// method for search film
    public ArrayList<Film> getAllFilms();
	
    // method for delete film by filmid
    public Boolean deleteFilm(int filmid);
    
    //made arraylist for search film
    ArrayList<Film> searchFilm(Film film);
    
    Boolean modifyFilm(Film film);

}



