package flp.cap.org.gen;

public class TestMain {
	public static void main(String[] args) {
		EmployeeUtil<CGEmployee> cg=new EmployeeUtil<CGEmployee>(new CGEmployee("Tom",2300));
		EmployeeUtil<CTSEmployee> cts=new EmployeeUtil<CTSEmployee>(new CTSEmployee("Jerry",2300));
		EmployeeUtil<CTSEmployee> cts1=new EmployeeUtil<CTSEmployee>(new CTSEmployee("Jerry",2300));
		
		EmployeeUtil<CGEmployee> cg1=new EmployeeUtil<CGEmployee>(new CGEmployee("Kamal",2400));
		
		cg.compareSalary(cg1);
		
		cts1.compareSalary(cts);
		
		cg.compareSalary(cts);
		
	}

}
