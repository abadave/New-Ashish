package com.Service;

import java.util.ArrayList;

import com.pojo.Customer;
import com.pojo.LoginUser;

public interface LoginService {public boolean isValidLogin(LoginUser loginUser);
public void saveCustomer(Customer customer);
public  ArrayList<Customer> getAllCustomer();
	

}