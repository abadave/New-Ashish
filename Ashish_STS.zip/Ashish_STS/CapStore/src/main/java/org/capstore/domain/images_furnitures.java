package org.capstore.domain;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;




@Entity
public class images_furnitures

{
	@Id
	@GeneratedValue
	private int image_id;
	private String image_front_view;

	private String image_side_view;

	private String image_back_view;

	private String image_multiple_view;

	
	@OneToOne	
	@JoinColumn(name="product_id_FK")	
	private product product;

	public String getImage_front_view() {
		return image_front_view;
	}

	public void setImage_front_view(String image_front_view) {
		this.image_front_view = image_front_view;
	}

	public String getImage_side_view() {
		return image_side_view;
	}

	public void setImage_side_view(String image_side_view) {
		this.image_side_view = image_side_view;
	}

	public String getImage_back_view() {
		return image_back_view;
	}

	public void setImage_back_view(String image_back_view) {
		this.image_back_view = image_back_view;
	}

	public String getImage_multiple_view() {
		return image_multiple_view;
	}

	public void setImage_multiple_view(String image_multiple_view) {
		this.image_multiple_view = image_multiple_view;
	}

	public product getProduct() {
		return product;
	}

	public void setProduct(product product) {
		this.product = product;
	}

	public images_furnitures(String image_front_view, String image_side_view, String image_back_view,
			String image_multiple_view, org.capstore.domain.product product) {
		super();
		this.image_front_view = image_front_view;
		this.image_side_view = image_side_view;
		this.image_back_view = image_back_view;
		this.image_multiple_view = image_multiple_view;
		this.product = product;
	}

	@Override
	public String toString() {
		return "images_furnitures [image_front_view=" + image_front_view + ", image_side_view=" + image_side_view
				+ ", image_back_view=" + image_back_view + ", image_multiple_view=" + image_multiple_view + ", product="
				+ product + "]";
	}

	

	


	}
 

