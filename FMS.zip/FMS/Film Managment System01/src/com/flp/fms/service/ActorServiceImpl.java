package com.flp.fms.service;
import java.util.Set;

import com.flp.fms.dao.ActorDaoImplForDB;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.Actor;
public class ActorServiceImpl implements IActorService{

	private IActorDao actorDao=new ActorDaoImplForDB();
	
	// Set method for Actor
	@Override
	public Set<Actor> getActors() {
		// TODO Auto-generated method stub
		return actorDao.getActors();
	}

}


