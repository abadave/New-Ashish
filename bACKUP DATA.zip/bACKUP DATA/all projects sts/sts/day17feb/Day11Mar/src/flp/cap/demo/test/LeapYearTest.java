package flp.cap.demo.test;

import static org.junit.Assert.*;

import org.junit.Test;

import flp.cap.demo.LeapYear;

public class LeapYearTest {
	
	/*1.Divisible by 4
	 *2.divisible by 100 and 400
	 *3.divisible by 100 but not by 400
	 * 4.not divided by 4 
	 * 5.negative no
	 */
	
	@Test
	public void testwhethernoisdivisibleby4(){
		LeapYear LY= new LeapYear();
     
		assertTrue(LY.isdivisibleby4(1900));
		assertTrue(LY.isdivisibleby100and400(1900));
		assertTrue(LY.isdivisibleby100butnotby400(1900));
			}

	
	/*@Test
	publ		fail("Not yet implemented");
ic void test() {
	}*/

}
