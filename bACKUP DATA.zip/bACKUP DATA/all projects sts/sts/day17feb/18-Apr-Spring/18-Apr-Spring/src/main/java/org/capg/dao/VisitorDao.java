package org.capg.dao;

import java.util.List;

import javax.sql.DataSource;

import org.capg._Apr_Spring.Visitor;

public interface VisitorDao {
	
	
public void setDataSource(DataSource dataSource);
	
	public void createVisitor(Visitor visitor);
	
	public void deleteVisitor(int visitId);
	
	public void updateVisitor(Visitor v);
	
	public Visitor searchVisitor(int visitId);
	
	public List<Visitor> getAllVisitor();

}
