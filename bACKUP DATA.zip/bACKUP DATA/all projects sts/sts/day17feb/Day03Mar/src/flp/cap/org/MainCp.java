package flp.cap.org;

public class MainCp {

	public static void main(String[] args) {
		CapGemInI asd=new CapGemInI();
		
	
		Thread t1=new Thread(){
			public void run(){
				asd.Printdetails("Capgemini");
			}
		};
		Thread t2=new Thread(){
			public void run(){
				asd.Printdetails("Welcomes");
			}
		};
		Thread t3=new Thread(){
			public void run(){
				asd.Printdetails("You");
			}
		};

		t1.start();
		
		t3.start();
		t2.start();
	}

}
