package com.flp.fms.view;

import java.util.Collection;
import java.util.Map;
import java.util.Scanner;

import com.flp.fms.domain.Film;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

public class Bootclass {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int option;
		UserInteraction userInteraction=new UserInteraction();
		IFilmService films=new FilmServiceImpl();
		IActorService asd=new ActorServiceImpl();
		String choice;
		// here we selecting one option from menu
		do{
		menuSelection();
		System.out.println("Enter your option:[1-6]");
		option=sc.nextInt();
		switch(option){
		
			case 1:
				Film film=userInteraction.addFilm(films.getLanguages(), films.getCategory(),asd.getActors());
				films.addFilm(film);
				System.out.println(film);
				
				break;
			case 2:
				int filmId1=userInteraction.readFilmId();
				film=films.searchFilms(filmId1);
				System.out.println("update");
		
				if(film==null)
					System.out.println("Film Not Present");

				else{
					System.out.println(film);
					Film film1=userInteraction.addFilm(films.getLanguages(),films.getCategory(),asd.getActors());
					film1.setFilmId(filmId1);
					films.updateFilm(film1);
					System.out.println(film1);
				}
				
				
				
				break;
			case 3:
				String choice2;
				do{
				deleteMenuSelection();
				System.out.println("Enter your choice: ");
				int opt1=sc.nextInt();
				
				switch(opt1){
				
				//DELETE BY ID
				case 1:
					System.out.println("Please enter film Id to delete: ");
				    int filmId=sc.nextInt();
					userInteraction.deleteFilmById(films.getAllFilms(),filmId);
					break;
				
				//DELETE BY TITLE
				case 2:
					System.out.println("Please enter film Title to delete: ");
				    String filmTitle=sc.next();
				    userInteraction.deleteFilmByTitle(films.getAllFilms(),filmTitle);
				    break;
				
				//DELETE BY RATING
				case 3:
					System.out.println("Please enter film Rating to delete: ");
				    int rating=sc.nextInt();
				    userInteraction.deleteFilmByRatings(films.getAllFilms(),rating);
					break;
					
				case 4:
					break;
				}
				System.out.println("Wish to do more deletion?[y|n]");
				choice=sc.next();
				}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
			
				break;
				
			case 4:
				Map<Integer, Film> film_lst1=films.searchfilm();
				Collection<Film> lst1=film_lst1.values();
				userInteraction.searchfilm(lst1);
				break;
			case 5:
				Map<Integer, Film>  film_lst= films.getAllFilms();
				Collection<Film> lst=film_lst.values();
				userInteraction.getAllFilm(lst);
				break;
			case 6:
				
		}System.out.println("Wish to do more Operation?[y|n]");
		choice=sc.next();
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		
		System.exit(0);
		
	}

	public static void menuSelection(){
		System.out.println("1.Add Film");
		System.out.println("2.Modify Film");
		System.out.println("3.Remove Film");
		System.out.println("4.Search Film");
		System.out.println("5.GetAll Film");
		System.out.println("6.Exit");
		
	}	
	
	//DELETE MENU
		public static void deleteMenuSelection(){
			
			System.out.println("1.Delete by ID");
			System.out.println("2.Delete by Title");
			System.out.println("3.Delete by Ratings");
			System.out.println("4.Exit");
			
		}

}
