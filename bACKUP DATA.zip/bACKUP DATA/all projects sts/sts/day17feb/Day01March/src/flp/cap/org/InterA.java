package flp.cap.org;

public interface InterA{
	
	public void show();
	
	
	

}
