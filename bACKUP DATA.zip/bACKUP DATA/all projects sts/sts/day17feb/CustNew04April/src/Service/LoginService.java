package Service;

import pojo.Customer;
//import com.pojo;
import pojo.LoginUser;

public interface LoginService {
	
	public boolean isValidLogin(LoginUser loginUser);
	public void saveCustomer(Customer customer);

}
