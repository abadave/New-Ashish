package org.capstore.domain;




import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

@Entity
public class coupon {
	@Id
	private int coupon_discount_id;
	private String discount_code;
	private double coupon_value;
	private double discount_percentage;
	//@DateTimeFormat(pattern="dd/MM/yy")
	@DateTimeFormat(pattern="dd-MMM-yyyy",iso=ISO.DATE)
	private Date creation_date;
	@DateTimeFormat(pattern="dd-MMM-yyyy",iso=ISO.DATE)
	private Date expiry_date;
	
	
	public coupon(){}
	
	
	public coupon(int coupon_discount_id, String discount_code, double coupon_value, double discount_percentage,
			Date creation_date, Date expiry_date) {
		super();
		this.coupon_discount_id = coupon_discount_id;
		this.discount_code = discount_code;
		this.coupon_value = coupon_value;
		this.discount_percentage = discount_percentage;
		this.creation_date = creation_date;
		this.expiry_date = expiry_date;
	}


	public int getCoupon_discount_id() {
		return coupon_discount_id;
	}


	public void setCoupon_discount_id(int coupon_discount_id) {
		this.coupon_discount_id = coupon_discount_id;
	}


	public String getDiscount_code() {
		return discount_code;
	}


	public void setDiscount_code(String discount_code) {
		this.discount_code = discount_code;
	}


	public double getCoupon_value() {
		return coupon_value;
	}


	public void setCoupon_value(double coupon_value) {
		this.coupon_value = coupon_value;
	}


	public double getDiscount_percentage() {
		return discount_percentage;
	}


	public void setDiscount_percentage(double discount_percentage) {
		this.discount_percentage = discount_percentage;
	}


	public Date getCreation_date() {
		return creation_date;
	}


	public void setCreation_date(Date creation_date) {
		this.creation_date = creation_date;
	}


	public Date getExpiry_date() {
		return expiry_date;
	}


	public void setExpiry_date(Date expiry_date) {
		this.expiry_date = expiry_date;
	}


	@Override
	public String toString() {
		return "Coupon [coupon_discount_id=" + coupon_discount_id + ", discount_code=" + discount_code
				+ ", coupon_value=" + coupon_value + ", discount_percentage=" + discount_percentage + ", creation_date="
				+ creation_date + ", expiry_date=" + expiry_date + "]";
	}
	
	
	

}

	
	
	
	

