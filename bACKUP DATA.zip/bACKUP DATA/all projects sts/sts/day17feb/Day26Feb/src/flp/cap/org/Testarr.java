package flp.cap.org;
import java.util.List;
import java.util.ListIterator;
import java.util.ArrayList;

public class Testarr {

	public static void main(String[] args) {
		List<String> mylst =new ArrayList<>();
		List<String>myass =new ArrayList<>(); 
		
		mylst.add("Tom");
		mylst.add("Engineer");
		mylst.add("100");
		mylst.add("4.2");
		mylst.add("ashish");
		mylst.add("power");
		mylst.add("Mumbai");
		
		myass.add("Jerry");
		myass.add("Mechanical");
		myass.add("200");
		myass.add("500");
		
		//int index=5;
	
	System.out.println(mylst);
		

	
/*ListIterator<String>litr=mylst.listIterator();

while (litr.hasNext()){
	
	System.out.print(litr.next()+ "--->");
}
System.out.println();

while (litr.hasPrevious()){
	
	System.out.print(litr.previous()+ "--->");
}*/

/*System.out.println("\n my collection size is:->" + mylst.size()); // here we get no. of elements in collection

System.out.println("my index is-->" + mylst.get(index));// here we get the next word of index, that we given input as index
*/
if(!mylst.isEmpty()){
	 System.out.println("My collection is not empty"); // here we get whether collection is empty or not
}
/*myass.addAll(mylst);

for(String awe: myass)
{
	 System.out.println("the new list will be-->" + myass);
	}
 */
 mylst.removeAll(mylst);
 System.out.println();
	
}



	}

	