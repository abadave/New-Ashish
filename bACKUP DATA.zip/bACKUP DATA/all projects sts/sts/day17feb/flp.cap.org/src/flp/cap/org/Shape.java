package flp.cap.org;

public interface Shape {
public static final float PI=3.15f;
void draw();
}
