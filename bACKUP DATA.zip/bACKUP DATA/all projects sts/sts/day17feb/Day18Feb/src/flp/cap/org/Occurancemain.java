package flp.cap.org;

public class Occurancemain {

	public static void main(String[] args) {
		Occurance op=new Occurance();
		op.getString();
		op.countCharacter();
		op.printCount();
	}

}
