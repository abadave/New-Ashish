package flp.cap.org;

public class MyThread extends Thread {
	
	
	static int i=0;
	int k;
	public void run(){
		do{
		if(i<10){
			for(k=0;k<2;k++,i++)
			{
			System.out.println(this.getName()+"   /"+"i="+i);
			}
		}
		
	}while(k!=2);
	}
	}