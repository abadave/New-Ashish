package flp.org.cap;

public class MainTest {

	public static void main(String[] args) {
	
		WareHouse wh1=new WareHouse();
		Producer p1=new Producer(wh1);
		Consumer c1=new Consumer(wh1);
		Thread t1=new Thread(p1);
		Thread t2= new Thread(c1);
		t1.start();
		t2.start();
		

	}

	}


