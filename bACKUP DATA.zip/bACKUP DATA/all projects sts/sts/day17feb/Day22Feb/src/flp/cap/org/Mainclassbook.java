package flp.cap.org;

public class Mainclassbook {
	
//public static void main (String [] args) {

	@Publisher(publisher_name="Ashish", published_date="12-june-93")
   Book bk= new Book();
	}



