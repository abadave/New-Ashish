package Accountd;
//import java.util.Scanner;
public class Account {
	
	int no=5;
	
	public void getAccno()
	{
		System.out.println("Acc_no-"+ no);

	}

}
