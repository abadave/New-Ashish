package flp.cap.org;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;


public class TestHashlink {
public static void main(String[] args) {
		
		ArrayList<EmployeeLinkHash> set=new ArrayList<>();
		
		set.add(new EmployeeLinkHash(101, "Ashish", "Badave", 12));
		set.add(new EmployeeLinkHash(103, "Zkash", "Badave", 17));
		set.add(new EmployeeLinkHash(104, "Cshish", "Kulkarni", 14));
		set.add(new EmployeeLinkHash(12, "Dshish", "Badave", 15));
		set.add(new EmployeeLinkHash(11, "Fshish", "Badave", 12));
		set.add(new EmployeeLinkHash(105, "Eshish", "Kulkarni", 11));
		set.add(new EmployeeLinkHash(16, "Ravi", "Sole", 10));
		set.add(new EmployeeLinkHash(17, "Supesh", "Jadhav", 110));
		set.add(new EmployeeLinkHash(108, "Tkshay", "Sagare", 123));

		Collections.sort(set,new Salarysort());

		
		//Collections.sort(set,new Firstnamesort());
		
	
		//Collections.sort(set,new Lastnamesort());
		
		
		Iterator<EmployeeLinkHash> itr=set.iterator();
		
		while(itr.hasNext())
			System.out.println(itr.next());
		
	}


}
