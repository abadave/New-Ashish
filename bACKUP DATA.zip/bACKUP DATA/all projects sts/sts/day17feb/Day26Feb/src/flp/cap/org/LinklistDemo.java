package flp.cap.org;

import java.util.LinkedList;

public class LinklistDemo {

	public static void main(String[] args) {
		
		LinkedList <Integer> lst=new LinkedList<>();
		lst.add(34);
		lst.add(89);
		lst.add(34);
		lst.add(123);
		lst.add(34);
		lst.add(12);
		
		
		System.out.println(lst);
		
		/*lst.removeFirst(); //here we removed first element
		System.out.println(lst);
	
	    lst.addFirst(2);// added any integer like 2, as first element
		System.out.println(lst);
		
		lst.addLast(7);
		System.out.println(lst);
		
		System.out.println(lst.getFirst());
		System.out.println(lst.getLast());
		
		
		lst.offer();
		System.out.println(lst);
		
		lst.peek();
		System.out.println(lst.peek());

		
		lst.poll();
		System.out.println(lst);
		
		
		lst.push(4);
		System.out.println(lst);
	    */
	
		System.out.println(lst.removeLastOccurrence(34));
	}

	
	}

