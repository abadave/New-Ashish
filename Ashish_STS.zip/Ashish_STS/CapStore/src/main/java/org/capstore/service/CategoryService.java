package org.capstore.service;
import java.util.List;

import org.capstore.domain.Category;
import org.capstore.domain.Discount;
import org.capstore.domain.Images_Electronics;
import org.capstore.domain.coupon;
import org.capstore.domain.product;
import org.capstore.domain.sub_category;


public interface CategoryService 
{
	public List<Category> getAllCategories();
	public List<sub_category> getAllSubCategories(Integer category_id);

	public void saveCategory(Category category);
	public List<sub_category> getsubcategory1();
	public List<product> getAllFurniture();
	public List<product> getAllKitchen();
	public List<product> getAllHome();
	public List<product> getmostVisitedFurniture();
	public List<product> getAscendingPrice();
	public List<product> getDescendingPrice();
	public List<product> getRating();
	public List<product> getCoupon();
	public void saveCoupon(coupon coupon);
	public void saveImage(Images_Electronics Images_Electronics );
	public void  saveDiscount(Discount discount);



}
