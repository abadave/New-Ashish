package flp.org.cap.thread2;

import flp.org.cap.Consumer;
import flp.org.cap.Producer;
import flp.org.cap.thread2.Warehouse;

public class MainTest2 {

	public static void main(String[] args) {
		Warehouse wh1=new Warehouse();
		Producer2 p1=new Producer2(wh1);
		Producer2 p2=new Producer2(wh1);
		Producer2 p3=new Producer2(wh1);
		Producer2 p4=new Producer2(wh1);
		
		
		Consumer2 c1=new Consumer2(wh1);
		
		Thread t1=new Thread(p1);
		Thread t2= new Thread(c1);
		Thread t3=new Thread(p2);
		Thread t4=new Thread(p3);
		Thread t5=new Thread(p4);
		
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();
	}

}
