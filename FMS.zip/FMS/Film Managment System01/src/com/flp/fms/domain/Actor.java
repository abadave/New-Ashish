package com.flp.fms.domain;

public class Actor {

	//private fields
	private int ActorId;
	private String FirstName;
	private String LastName;
	
	// no argument constructor
	public Actor() {
	}

    // argument constructor
	public Actor(int actorId, String firstName, String lastName) {
		super();
		ActorId = actorId;
		FirstName = firstName;
		LastName = lastName;
		
	}
    
	//getter setter
	public int getActorId() {
		return ActorId;
	}

	public void setActorId(int actorId) {
		ActorId = actorId;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	
	
    // to string method
	@Override
	public String toString() {
		return "Actor [ActorId=" + ActorId + ", FirstName=" + FirstName + ", LastName=" + LastName + 
				"]";
	}
	
	

}
