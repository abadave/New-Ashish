package day17feb;

public class Circle extends Shape{

	Shape crl= new Circle();
	
		
}
