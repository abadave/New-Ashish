package org.capstore.dao;
import java.util.List;
import org.capstore.domain.Category;
import org.capstore.domain.product;


public interface ProductDao 

{
	public List<Object> getAllFurniture();
}
