package flp.cap.org;

public class Empmain {
	
	public static void main(String[] args) {
		EmployeeValid a=new EmployeeValid();
		a.getempldetails();
		a.printempdetails();

}
}
