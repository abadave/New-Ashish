package flp.cap.jsp.handle;

import java.io.IOException;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class Today extends SimpleTagSupport{

	private Date mydate;

public Date getMydate(){
	return mydate;
}
public void setMydate(){
	this.mydate= mydate;
}

public void doTag() throws JspException, IOException {
	JspWriter out=getJspContext().getOut();
	StringWriter str=new StringWriter();
	getJspBody().invoke(str);
	DateFormat dd= new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
	Date date = new Date();
	
	out.println(dd.format(date));
	super.doTag();
}
}
