package flp.cap.org;
import java.util.Scanner;
public class StudentAssgn {
	int stu_id;
	String stud_name;
	float grade, attendance;
	
	
	Scanner sc= new Scanner(System.in);
	
	public void getstuddetails(){
	
		System.out.println("Enter the student id");
		stu_id=sc.nextInt();
	    
		System.out.println("Enter the student name");
		stud_name=sc.next();
	}
	
	public void displaygrade(){
		
		System.out.println("The grade of student is-->" + grade);
	}
    public void displayattendance(){
		
		System.out.println("The attendance of student is-->" + attendance);
	
}
    
}
