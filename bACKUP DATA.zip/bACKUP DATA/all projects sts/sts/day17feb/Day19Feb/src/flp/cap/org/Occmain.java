package flp.cap.org;

public class Occmain {
	public static void main(String[] args) {
		Occurance op=new Occurance();
		op.getString();
		op.countCharacter();
		op.printCount();
	}


}
