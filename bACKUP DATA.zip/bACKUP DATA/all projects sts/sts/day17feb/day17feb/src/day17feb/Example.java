package day17feb;

public class Example {

	//public static void main(String[] args) {
		// TODO Auto-generated method stub
static int count, num;

static
{ System.out.println("Satic Block");

}
{
	System.out.println("Normal Block");
}

public void getprint(){
	System.out.println("Hiii");
}

 public Example()
 { Example ex=new Example();
 
 ex.getprint();
}
 
}
