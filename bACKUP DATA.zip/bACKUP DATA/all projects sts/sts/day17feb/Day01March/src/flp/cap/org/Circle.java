package flp.cap.org;

public class Circle<T>
{ private T obj;
public Circle (T obj)
{
	this.obj=obj;
	
	}

public void getshow()
{
	System.out.println("T-->" + obj + obj.getClass().getName());
}
	}

