package flp.org.cap.exception;

public class Demo {

	public static void main(String[] args) {
//int num1, num2, ans=0;
try{
		
if (args.length==2){
int num1 = Integer.parseInt(args[0]);
int num2= num1= Integer.parseInt(args[1]);

int ans;
	ans= num1/num2;
}
 }catch(ArithmeticException|NumberFormatException|ArrayIndexOutOfBoundsException ex){
	 ex.printStackTrace();
 }
finally{
	System.out.println("Finally Executed");
}
	}
}


