package Balancep;
import Accountd.*;

public class Balance {

	public static void main (String[] args)
	{
	Account a= new Account();
	
	
	a.getAccno();
}
}
