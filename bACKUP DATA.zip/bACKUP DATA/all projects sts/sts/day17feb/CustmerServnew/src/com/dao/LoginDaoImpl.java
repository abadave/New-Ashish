package com.dao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.pojo.Customer;
import com.pojo.LoginUser;

public class LoginDaoImpl implements LoginDao{

	@Override
	public boolean isValidLogin(LoginUser loginUser) {
		boolean flag=false;
		Connection con=getConnection();
		String sql="select * from user1 where id=? and pass=?";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, loginUser.getUserName());
			pst.setString(2, loginUser.getUserPwd());
			
			ResultSet rs=pst.executeQuery();
			
			if(rs.next())
				flag=true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return flag;
	}

	
	public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/nikunj","root","Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return connection;
	}


	@Override
	public void saveCustomer(Customer customer) {
		
		Connection con=getConnection();
		
		String sql="insert into customer1(firstName,lastName,address,gender,RegDate,RegFees,CustomerType)"
											+ "	 values(?,?,?,?,?,?,?)";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, customer.getFirstName());
			pst.setString(2, customer.getLastName());
			pst.setString(3, customer.getAddress());
			pst.setString(4, customer.getGender());
			pst.setDate(5,new Date(customer.getRegDate().getTime()));
			pst.setDouble(6, customer.getRegFees());
			pst.setString(7, customer.getCusType());
			
			
			int count=pst.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}@SuppressWarnings("static-access")
	@Override
	public ArrayList<Customer> getAllCustomer() {
ArrayList<Customer> customer=new ArrayList<>();
		
		String sql="select * from Customer1";
		Connection con=getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
				Customer cus=new Customer();
				
				cus.setCusId(rs.getInt(1));
				cus.setFirstName(rs.getString(2));
				cus.setLastName(rs.getString(3));
				cus.setAddress(rs.getString(4));
				cus.setGender(rs.getString(5));
				cus.setRegDate((rs.getDate(6).valueOf(rs.getDate(6).toString())));
				cus.setRegFees(rs.getDouble(7));
				cus.setCusType(rs.getString(8));
				
				
				//Adding the employee into arraylist
				customer.add(cus);
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return customer;
	}


}