package flp.cap.org;

public interface CustomerDAO {

	
		public void storeCustomer(Customer c);
		public void listAllCustomers();
		public void searchCustomer(int custId);

	}

