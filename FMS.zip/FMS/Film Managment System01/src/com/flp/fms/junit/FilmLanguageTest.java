package com.flp.fms.junit;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

public class FilmLanguageTest {
	  //TEST CASES FOR Language
			//1.Object is null
			//2.duplicate Language entry should not be allowed
			//3.Not Valid Language
	        //4.get all Languages
	IFilmService filmService=new FilmServiceImpl();

	@Test
	public void isLanguageObjectIsNull() {
		
		Language language=null;
		assertNotEquals(language, filmService.getLanguages());
		
	} 
	@Test
	public void noDuplicateLanguageEntry() {
		
		Language language=new Language(3,"English");
		assertNotEquals(language,filmService.getLanguages());
		
	}
	@Test
	public void isNotValidLanguage() {
		
		Language language=new Language(20,"ABC");
		assertNotEquals(language,filmService.getLanguages());
		
	}
	
	
	//TEST CASE FOR LIST OF LANGUAGES
		@Test
		public void GetAllLanguages(){
			

			List<Language>languages=new ArrayList<>();
			
			languages.add(new Language(1, "English"));
			languages.add(new Language(2, "Hindi"));
			languages.add(new Language(3, "Marathi"));
			languages.add(new Language(4, "Telagu"));
			languages.add(new Language(5, "Tamil"));
			assertEquals(languages, filmService.getLanguages());
			
		}
}