package org.capstore.service;

import java.util.List;

import org.capstore.pojo.Discount;

public interface Discount_Service {
	
	
	public void saveDiscount(Discount discount);
	public List<Discount> getAllDiscounts() ;
	public void deleteDiscount(Integer d_id);

}
