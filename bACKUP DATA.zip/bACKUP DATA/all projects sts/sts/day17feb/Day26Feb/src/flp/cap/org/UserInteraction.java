package flp.cap.org;
import java.util.Date;
import java.util.Scanner;

public class UserInteraction{
	public Customer getCustomerDetails()
{
	Customer cus=new Customer();
	int cusId;
	String cusName;
	long regfee;
	String date;
	String address;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter customer id");
	cusId=sc.nextInt();
	System.out.println("Enter customer name");
	cusName=sc.next();
	System.out.println("Enter Registration fees");
	regfee=sc.nextLong();
	System.out.println("Enter date");
	date=sc.next();
	System.out.println("Enter address");
	address=sc.next();
	cus.setCustId(cusId);
	cus.setCustName(cusName);
	cus.setRegFees(regfee);
	Date d=new Date(date);
	cus.setRegDate(d);
	cus.setAddress(address);
	return cus;

}


}
 


