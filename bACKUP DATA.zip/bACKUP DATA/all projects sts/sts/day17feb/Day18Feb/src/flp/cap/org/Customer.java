package flp.cap.org;
import java.util.Scanner;
public class Customer {

	int cust_id;
	String Cust_name;
	CustType ct;
	
	int Reg_fees;
Scanner sc=new Scanner (System.in);

	public void getcustmordetails()
	{
		System.out.println("Enter the Customer id");
		cust_id=sc.nextInt();
		System.out.println("Enter the Customer name");
		Cust_name=sc.next();
		//System.out.println("Enter the Customer type");
		//Cust_type=sc.next();
		System.out.println("Enter the Registration fees");
		Reg_fees=sc.nextInt();
	}
	
	public void getcusttype()
	{
		System.out.println("1.SILVER");
		System.out.println("2.GOLD");
		System.out.println("3.DIAMOND");
		System.out.println("4.PLATINUM");
		
		System.out.println("Enter your choice");
		int choice=sc.nextInt();
	
		switch(choice){
		case 1:
			ct=CustType.SILVER;
			
		case 2:
			ct=CustType.GOLD;
				
		case 3:
			ct=CustType.DIAMOND;
				
		case 4:
			ct=CustType.PLATINUM;
			
		
		}
		
		}
	
	
    public  void printcustomerdetails()
{
	System.out.println(cust_id +"\t"+ Cust_name+ "\t"+ Reg_fees+ ct);;
}
	}
