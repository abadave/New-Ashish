package flp.cap.org;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str1="tom";
		String str2="tom";
	String mystr= new String("tom");
			
	System.out.println(str1.equals(str2));
	System.out.println(str1.equals(mystr));
	
	}

}
