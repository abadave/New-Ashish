package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;

import com.flp.fms.domain.Actor;


public class ActorDaoImplForDB implements IActorDao{

	@Override
	public Set<Actor> getActors() {
		
		Set<Actor> actors=new HashSet<>();
		/*actors.add(new Actor(101,"Amitabh","Bacchan"));
		actors.add(new Actor(102,"Shahrukh","Khan"));
		actors.add(new Actor(103,"Hritik","Roshan"));
		actors.add(new Actor(104,"Abhishek","Bacchan"));
		actors.add(new Actor(105,"Amir","Khan"));
		*/
		
// connection to DataBase for Actor		
Connection con=getConnection();
		
		String sql="select * from ACTOR";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Actor actor1=new Actor();
				actor1.setActorId(rs.getInt(1));
				actor1.setFirstName(rs.getString(2));
				actor1.setLastName(rs.getString(3));
				System.out.println(actor1);
				actors.add(actor1);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return actors;
		
	}

	
	// Database connection
public static Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		System.out.println("connection essablished");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/FMSDATABASE","root","Pass1234");
			System.out.println("Driver Registered");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return connection;
	}
	
}
