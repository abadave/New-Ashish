package flp.cap.org;

public class Custmain {

	public static void main(String[] args) {
		
		Customer c=new Customer();
		c.getcustmordetails();
		c.getcusttype();
		c.printcustomerdetails();
		
		// TODO Auto-generated method stub

	}

}
