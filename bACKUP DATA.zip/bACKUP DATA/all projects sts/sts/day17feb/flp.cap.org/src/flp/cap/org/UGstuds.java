package flp.cap.org;

public class UGstuds {
	StudentAssgn [] abc;
	int rollno;
	
	public  UGstuds() {
		abc=new StudentAssgn[50];
	}

}
