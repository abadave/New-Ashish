package com.flp.fms.service;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface IFilmService {
	// to get language
	public List<Language> getLanguages();
	// to get category
	public List<Category> getCategory();
	// adding film
	public void addFilm(Film film);
	// get all film method
	public Map<Integer, Film> getAllFilms();
	// search film method
	public Map<Integer, Film> searchfilm();
	// remove film method
	public Map<Integer, Film> removefilm();
	// search film using filmid1 object
	public Film searchFilms(int filmId1);
    // update film
	public void updateFilm(Film film1);
}

	
	

