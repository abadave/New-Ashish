package flp.cap.org;
import java.util.Scanner;

public class Palindrome {
	String string;
	public void getString()
	{
		System.out.println("Enter string");
		Scanner sc=new Scanner(System.in);
		string=sc.next();
	}
	public void checkPalindrome()
	{
			int count=0;
		for(int i=0,j=string.length()-1;i<=(string.length()+1)/2-1;i++,j--)
		{
			if(string.charAt(i)!=string.charAt(j))
			{
				count++;
				break;
			}
		}
		if(count==0)
		{
			System.out.println("Palindrome");
		}
		else
		{
			System.out.println("Not Palindrome");
		}
	}
}



