package com.flp.fms.dao;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmDaoImplForList implements IFilmDao{
	private Map<Integer, Film> film_Repository=new HashMap<>();

	// adding language using list interface
	@Override
	public List<Language> getLanguages() {
		List<Language> languages=new ArrayList<>();
		languages.add(new Language(1, "English"));
		languages.add(new Language(2, "Hindi"));
		languages.add(new Language(3, "Telegu"));
		languages.add(new Language(4, "Marathi"));
		languages.add(new Language(5, "Kannad"));
		languages.add(new Language(6, "Tamil"));
		languages.add(new Language(7, "Malayalam"));
		
		
		return languages;
	}

	// adding category using list interface
	public List <Category> getCategory(){
		List<Category> category=new ArrayList<>();
		category.add(new Category(1, "Comedy"));
		category.add(new Category(2, "Horror"));
		category.add(new Category(3, "Adventure"));
		category.add(new Category(4, "Petriotic"));
		category.add(new Category(5, "Romantic"));
		category.add(new Category(6, "Revenge base"));
		
		
		return category;
		
	}
	//CURD Operation
		@Override
		public void addFilm(Film film) {
			film_Repository.put(film.getFilmId(), film);
			
		}


		@Override
		public Map<Integer, Film> getAllFilms() {
			
			return film_Repository;
		
		}

		@Override
		public Map<Integer, Film> searchfilm() {
			// TODO Auto-generated method stub
			return film_Repository;
			
		}

		@Override
		public Map<Integer, Film> removefilm() {
			// TODO Auto-generated method stub
			return film_Repository;
		}
	
		public void updateFilm(Film film1) {
			 
			addFilm(film1);
			
		}

		// search film method logic
		@Override
		public Film searchFilm(int filmId1) {
			Map<Integer, Film> filmList=getAllFilms();
			Collection<Film>filmList1=filmList.values();
			Film filmCurrent=new Film();
			boolean flag=false;
			for(Film film:filmList1)
			{
				if(filmId1==film.getFilmId())
				{
					System.out.println("Film is exists");
					System.out.println(film);
					filmCurrent=film;
					flag=true;
					break;
				}
			}
			
			return filmCurrent ;
		}
		}
		

