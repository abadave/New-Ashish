package com.flp.fms.domain;

import java.util.Date;
import java.util.List;
import java.util.Set;

public class Film {

	private int FilmId;
	private String title;
	private String description;
	private Date releaseYear;
	private List<Language> languages;	
	private Language originalLanguage;
	private Date rentalDuration;
	private int length;
	private double replacementCost;
	private int ratings;
	private String specialFeatures;
	private Set<Actor> actors;
	private Category category;
	
     public Film() {}

	public Film(int filmId, String title, String description, Date releaseYear, List<Language> language,
			Language originallanguage, Date rentalDuration, int length, double replacementCost, int ratings,
			String specialFeatures, List<Actor> actors, Category category) {
		super();
		FilmId = filmId;
		this.title = title;
		this.description = description;
		this.releaseYear = releaseYear;
		this.languages = languages;
		this.originalLanguage = originalLanguage;
		this.rentalDuration = rentalDuration;
		this.length = length;
		this.replacementCost = replacementCost;
		this.ratings = ratings;
		this.specialFeatures = specialFeatures;
		this.actors = (Set<Actor>) actors;
		this.category = category;
	}

	public int getFilmId() {
		return FilmId;
	}

	public void setFilmId(int filmId) {
		FilmId = filmId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getReleaseYear() {
		return releaseYear;
	}

	public void setReleaseYear(Date releaseYear) {
		this.releaseYear = releaseYear;
	}

	public List<Language> getLanguage() {
		return languages;
	}

	public void setLanguage(List<Language> language) {
		this.languages = language;
	}

	public Language getOriginallanguage() {
		return originalLanguage;
	}

	public void setOriginallanguage(Language originallanguage) {
		this.originalLanguage = originallanguage;
	}

	public Date getRentalDuration() {
		return rentalDuration;
	}

	public void setRentalDuration(Date rentalDuration) {
		this.rentalDuration = rentalDuration;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public double getReplacementCost() {
		return replacementCost;
	}

	public void setReplacementCost(double replacementCost) {
		this.replacementCost = replacementCost;
	}

	public int getRatings() {
		return ratings;
	}

	public void setRatings(int ratings) {
		this.ratings = ratings;
	}

	public String getSpecialFeatures() {
		return specialFeatures;
	}

	public void setSpecialFeatures(String specialFeatures) {
		this.specialFeatures = specialFeatures;
	}

	public Set<Actor> getActors() {
		return (Set<Actor>) actors;
	}

	public void setActors(Set<Actor> actors) {
		this.actors = (Set<Actor>) actors;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "Film [FilmId=" + FilmId + ", title=" + title + ", description=" + description + ", releaseYear="
				+ releaseYear + ", language=" + languages + ", originallanguage=" + originalLanguage
				+ ", rentalDuration=" + rentalDuration + ", length=" + length + ", replacementCost=" + replacementCost
				+ ", ratings=" + ratings + ", specialFeatures=" + specialFeatures + ", actors=" + actors + ", category="
				+ category + "]";
	}

     
	
}


