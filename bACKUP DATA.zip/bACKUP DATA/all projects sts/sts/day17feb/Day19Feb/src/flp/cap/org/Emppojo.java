package flp.cap.org;

public class Emppojo {

}
