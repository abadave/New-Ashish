package flp.cap.org;

public class MainMulti {

	public static void main(String[] args) throws InterruptedException {
	
		Multiplication t1=new Multiplication(3);
		Multiplication t2=new Multiplication(2);
		Multiplication t3=new Multiplication(8);
		
		Thread a1=new Thread (t1);
		Thread a2=new Thread (t2);
		Thread a3=new Thread (t3);
       
		a1.start();
		a1.join();
		
		
		a2.start();
		a3.start();
	}

}
