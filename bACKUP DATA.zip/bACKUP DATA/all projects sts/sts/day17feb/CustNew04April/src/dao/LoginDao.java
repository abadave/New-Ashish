package dao;


import pojo.Customer;
import pojo.LoginUser;

public interface LoginDao {
	
	public boolean isValidLogin(LoginUser loginUser) ;
	public void saveCustomer(Customer customer);

}
