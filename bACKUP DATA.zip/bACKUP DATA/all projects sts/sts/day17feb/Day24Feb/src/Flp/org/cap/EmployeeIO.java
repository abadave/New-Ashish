package Flp.org.cap;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class EmployeeIO {

	public static void main(String[] args) {
		int empid;
		String empname;
		double salary;
		boolean isPermanent;
		String gender;
		File file=new File("D:\\Ashish_Apple\\employeedetails.txt");
	   
		
	   FileOutputStream fout=null;
		DataOutputStream dout=null;
		String choice;
		try{
		fout= new FileOutputStream(file);
		dout= new DataOutputStream(fout);
	   do{
		Scanner sc=new Scanner(System.in);
		   
		   System.out.println("Enter the emp id");
		   empid=sc.nextInt();
		   
		   System.out.println("Enter the emp name");
		   empname=sc.next();
		   
		   System.out.println("Enter the emp salary");
		   salary=sc.nextDouble();
		   
		   System.out.println("Enter the emp status");
		   isPermanent=sc.nextBoolean();
		   
		   System.out.println("Enter the emp gender");
		   gender=sc.next();
		 
			dout.writeInt(empid);
			dout.writeChars(gender);
			dout.writeDouble(salary);
			dout.writeBoolean(isPermanent);
			dout.writeChars(empname);
			
			System.out.println("Wish to continue? [y|n]");
			choice=sc.next();
			
	   }while (choice.charAt(0)=='Y'||choice.charAt(0)=='y');
	   
	   System.out.println("Empid-" + empid+ "\nempname-"+ empname +"\nsalary-"+ salary+ "\npermenet" + isPermanent +"gender"+ gender);
			
      	}catch (FileNotFoundException ex){
			ex.printStackTrace();
		}
		catch (IOException ex){
		ex.printStackTrace();
		}  
}
}
