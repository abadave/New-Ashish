package flp.org.cap;

import java.util.Stack;

public class WareHouse {
	
	
	// it is for illeagal moniter state exception
	private Stack<Integer>stack=new Stack<Integer>();
	
	public int add(int x){
		
		if(stack.size()==10)
			try {
				wait();
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		
		return stack.push(x);
		
		
	}
	
	public  int remove(){
		if(stack.isEmpty())
			try {
				wait();
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		System.out.println(stack.pop());
		
		return stack.pop();
		
	}

}
