package flp.cap.org;

@Publisher(publisher_name="Ashish", published_date = "12-June-1993")
public class Book {
	@Publisher(publisher_name="Ashish", published_date = "12-June-1993")
	private String publisher_name;
	private String published_date;
	
	public Book(){}
	
	public Book(String publisher_name, String published_date) {
		super();
		this.publisher_name = publisher_name;
		this.published_date = published_date;
	}
	public String getpublisher_name() {
		return publisher_name;
	}

	
	@Publisher(publisher_name="Chikya", published_date = "12-June-1993")
	public void setpublisher_name(String publisher_name) {
		this.publisher_name = publisher_name;
	}
	

	
	
	


}

