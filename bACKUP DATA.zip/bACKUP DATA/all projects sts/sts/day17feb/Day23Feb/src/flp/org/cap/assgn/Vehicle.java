package flp.org.cap.assgn;

import java.util.Scanner;

public class Vehicle  {
		
		
		int vid;
		String vname;
		String direction;

		public static void main(String[] args) {
			
			
			try{
				
				Vehicle V = new Vehicle();
				
				System.out.println("Enter the vid:");
				Scanner sc = new Scanner(System.in);
				V.vid = sc.nextInt();
				
				System.out.println("Enter the vehicle name:");
				V.vname=sc.next();
				
				
				System.out.println("Enter the vehicles direction :");
				V.direction=sc.next();
				
			
				if(V.direction.equals("same"))
				{
					throw new InvalidVehicleExveption ("Direction should be different else vehicle will collide");
					
				}
				
				
				
				
				
			}
			catch(Exception e)
			{
				
				System.out.println(e.getMessage());
			}
			
			
			
			
			
			

		}
}
