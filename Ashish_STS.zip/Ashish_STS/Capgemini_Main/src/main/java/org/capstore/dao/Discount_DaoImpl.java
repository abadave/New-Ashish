package org.capstore.dao;

import java.util.List;

import org.capstore.pojo.Discount;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller("discountDao")
public class Discount_DaoImpl implements Discount_Dao {

	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void saveDiscount(Discount discount) {
		sessionFactory.getCurrentSession().save(discount);
		

	}

	@Override
	public List<Discount> getAllDiscounts() {
		return sessionFactory.getCurrentSession().createQuery("from discount").list();
		
	}

	@Override
	public void deleteDiscount(Integer d_id) {
		Discount discount=(Discount) sessionFactory.getCurrentSession().get(Discount.class, d_id);
		if(discount!=null)
			sessionFactory.getCurrentSession().delete(discount);
	}

}
