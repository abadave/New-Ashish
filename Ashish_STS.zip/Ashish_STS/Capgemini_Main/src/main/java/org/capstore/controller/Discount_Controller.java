package org.capstore.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.capstore.pojo.Discount;
import org.capstore.service.Discount_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller

public class Discount_Controller {
	

	@Autowired
	private Discount_Service discount_Service;

	/*@RequestMapping("/welcome")
	public String showAccountPage(Map<String, Object> map){
		
				map.put( "discount", new Discount());
				map.put("discounttypes",getAllDiscountType().values());
				map.put("discounts", discount_Service.getAllDiscounts());
			
				return "Discount_page";
	}*/
	
	

	
	
	@RequestMapping(value="/saveDiscount",method=RequestMethod.POST)
	public ModelAndView saveDiscount(@Valid @ModelAttribute("discount") Discount discount,
			BindingResult result){
		
		if(!result.hasErrors()){
			System.out.println(discount);
			discount_Service.saveDiscount(discount);
			return new ModelAndView("redirect:welcome","discounttypes", getAllDiscountType().values());
		}else
		{
			return new ModelAndView("Discount_page","discounttypes", getAllDiscountType().values());
		}
	
	}

	@RequestMapping(value="/discount",method=RequestMethod.GET,
			produces={"application/json"})
	public  String getAll()
	{
		/*List<Category> categories=categoryService.getAllCategories();
		map.put("categories", categories);
		System.out.println(categories);*/
		return "Discount_page";
	}
	
	
	/*
	@RequestMapping("/discount")
	public String show(){
		
				
	return "Discount";
	}*/
	
	
public Map<Integer, String> getAllDiscountType(){
		
		Map<Integer, String> maps=new HashMap<>();
		
		maps.put(1,"Savings");
		maps.put(2,"Current");
		maps.put(3,"Loan");
		maps.put(4,"RD");
		maps.put(5,"FD");
		
		return maps;
		
	}

}
