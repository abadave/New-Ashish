package timepasss;

public class timepass implements Runnable
{
String msg = "default";
public timepass(String s)
{
msg = s;
}
public void run( )
{
System.out.println(msg);
}
public static void main(String args[])
{
new Thread(new timepass("String1")).run();
new Thread(new timepass("String2")).run();
System.out.println("end");
}
}
