package org.capstore.dao;
import java.util.List;
import org.capstore.domain.product;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class ProductDaoImpl
{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public List<Object> getAllFurniture()
	{
		
		
		return sessionFactory.getCurrentSession().createQuery("SELECT product.product_id,product.product_name,images_furnitures.image_front_view FROM product , images_furnitures WHERE product.product_id = images_furnitures.product_id").list();
		
	}
	
	
}
