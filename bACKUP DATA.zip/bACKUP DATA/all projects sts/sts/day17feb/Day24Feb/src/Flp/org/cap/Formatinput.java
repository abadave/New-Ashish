package Flp.org.cap;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Formatinput {

	public static void main(String[] args) {

		File file=new File("D:\\Ashish_Apple\\badave.txt");
		FileInputStream fin=null;
		DataInputStream din=null;
		try{
			fin= new FileInputStream(file);
			din= new DataInputStream(fin);
	int eid=din.readInt();
	char gender=din.readChar();
	double sal=din.readDouble();
	boolean status=din.readBoolean();
	String ename=din.readLine();
	
	System.out.println("Emp id-" + eid + "\nemp name-"+ ename +"\nsalary-" +sal +"\nispermenant-" + status + "\ngender-" + gender);
		}
		catch (FileNotFoundException ex){
		ex.printStackTrace();
	}
	catch (IOException ex){
	ex.printStackTrace();}
		}
}
