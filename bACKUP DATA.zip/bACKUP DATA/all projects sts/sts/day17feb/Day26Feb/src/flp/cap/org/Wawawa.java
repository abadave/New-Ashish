package flp.cap.org;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.TreeSet;



public class Wawawa {
	public static void main(String[] args) {
		List mylst =new ArrayList<>();
	
		mylst.add("pune"); mylst.add("chenn");
		mylst.add("hyd");  mylst.add("mum");
		mylst.add("ben"); mylst.add(3.14f);
		
		
	ListIterator it=mylst.listIterator();
it.next();
it.previous();
/*it.next();
it.hasPrevious();
it.next();
it.next();
it.previous();
it.next();
it.previous();
*/
System.out.println(it.next());

/*while(it.hasNext()){
		Object obj=it.next();
		if(obj.equals(100));
			mylst.remove();*/
	}



	}
