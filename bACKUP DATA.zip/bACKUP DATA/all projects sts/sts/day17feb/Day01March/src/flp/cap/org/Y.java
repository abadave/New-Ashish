package flp.cap.org;

public class Y implements InterA{
	
	public void show()
	{
		System.out.println("Print class Y");
	}

}
