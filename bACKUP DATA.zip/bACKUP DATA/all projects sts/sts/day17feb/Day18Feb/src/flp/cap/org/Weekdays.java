package flp.cap.org;

public enum Weekdays {

	//public static void main(String[] args) {
		// TODO Auto-generated method stub

	MON, TUE,WED,THU, FRI,SAT,SUN;

}
