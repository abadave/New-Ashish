package flp.org.cap;

public class Validation {


	    
		public static boolean isValidsalary(double salary){
			if (salary>=20000 && salary<=50000)
			return true;
				//System.out.println("Valid Salary");
			
			else
			{
				throw new Invalid("Invalid salary");
			}
}
}
