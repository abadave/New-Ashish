package flp.org.cap.assgn;


	public class ExcepCommnd extends Exception {
		
		
		public ExcepCommnd(String s)
		{
			
			
			super(s);
			
			
		}

	

}
