package flp.cap.org;
import java.util.Scanner;
import java.util.Date;

public class EmployeeValid {

	int emp_id;
	String kinid, firstname, lastname;
	String address, email, mobileno;
	
	public int getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}
	public String getKinid() {
		return kinid;
	}
	public void setKinid(String kinid) {
		this.kinid = kinid;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	@Override
	public String toString() {
		return "EmployeeValid [emp_id=" + emp_id + ", kinid=" + kinid + ", firstname=" + firstname + ", lastname="
				+ lastname + ", address=" + address + ", email=" + email + ", mobileno=" + mobileno + ", getEmp_id()="
				+ getEmp_id() + ", getKinid()=" + getKinid() + ", getFirstname()=" + getFirstname() + ", getLastname()="
				+ getLastname() + ", getAddress()=" + getAddress() + ", getEmail()=" + getEmail() + ", getMobileno()="
				+ getMobileno() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	
	
}
	