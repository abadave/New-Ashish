package org.capstore.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Discount 
{
	@Id 
	private int d_id;
	
	private String d_code;
	private Double d_percent;
	private Date creation_date;
	private Date expiry_date;
	
	
	
	
	public Discount(){}




	public int getD_id() {
		return d_id;
	}




	public void setD_id(int d_id) {
		this.d_id = d_id;
	}




	public String getD_code() {
		return d_code;
	}




	public void setD_code(String d_code) {
		this.d_code = d_code;
	}




	public Double getD_percent() {
		return d_percent;
	}




	public void setD_percent(Double d_percent) {
		this.d_percent = d_percent;
	}




	public Date getCreation_date() {
		return creation_date;
	}




	public void setCreation_date(Date creation_date) {
		this.creation_date = creation_date;
	}




	public Date getExpiry_date() {
		return expiry_date;
	}




	public void setExpiry_date(Date expiry_date) {
		this.expiry_date = expiry_date;
	}




	public Discount(int d_id, String d_code, Double d_percent, Date creation_date, Date expiry_date) {
		super();
		this.d_id = d_id;
		this.d_code = d_code;
		this.d_percent = d_percent;
		this.creation_date = creation_date;
		this.expiry_date = expiry_date;
	}




	@Override
	public String toString() {
		return "Discount [d_id=" + d_id + ", d_code=" + d_code + ", d_percent=" + d_percent + ", creation_date="
				+ creation_date + ", expiry_date=" + expiry_date + "]";
	}
	
	
	
	
}
