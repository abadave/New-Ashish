package flp.cap.org;

public class BookDaoImp implements BookDAO {

	Book[] books;
	int index;
	
	public  BookDaoImp() {
		books=new Book[50];
	}

	@Override
	public void savebook(Book book) {
		books[index]=book;
		index++;
		
	}

	@Override
	public void listofallbook() {
		// TODO Auto-generated method stub
		
	}



}


