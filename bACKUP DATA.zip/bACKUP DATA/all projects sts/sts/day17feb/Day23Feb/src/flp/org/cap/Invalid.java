package flp.org.cap;

public class Invalid extends Exception{
	
public Invalid(String msg){}
	
}
