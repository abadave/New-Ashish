package flp.cap.org;

public class Test {

	public static void main(String[] args) {
		Myclass<InterA> objA=new Myclass<InterA>(new X());
		Myclass<InterA> objB=new Myclass<InterA>(new Y());
		
		objA.printClass();
		objB.printClass();

	}
 
	}

