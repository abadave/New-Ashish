package Ashish;
import java.sql.*;
public class JDBC_exm {

	public static void main(String[] args) throws Exception{
		
		Class.forName("com.mysql.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/javaflp","root", "Pass1234");
		Statement stat=con.createStatement();
       
		ResultSet rs=stat.executeQuery("select Firstname, Lastname from Student3");
        while(rs.next())
        {
        	System.out.println(rs.getString(1));
        }
		con.close();
	}
}
