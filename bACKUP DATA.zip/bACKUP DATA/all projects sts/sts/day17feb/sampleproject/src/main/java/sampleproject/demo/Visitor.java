package sampleproject.demo;

public class Visitor {
	
	private int visitId;
	private String visitName;
	
	private Address address;

	public Visitor(){}
	
	public Visitor(int visitId, String visitName, Address address) {
		super();
		this.visitId = visitId;
		this.visitName = visitName;
		this.address = address;
	}

	public int getVisitId() {
		return visitId;
	}

	public void setVisitId(int visitId) {
		this.visitId = visitId;
	}

	public String getVisitName() {
		return visitName;
	}

	public void setVisitName(String visitName) {
		this.visitName = visitName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Visitor [visitId=" + visitId + ", visitName=" + visitName + ", address=" + address + "]";
	}
	
}
