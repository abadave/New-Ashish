package flp.cap.org;
import java.util.Scanner;

public class Pattern {

		String string;
		public void getString()
		{
			System.out.println("Enter string");
			Scanner sc=new Scanner(System.in);
			string=sc.next();
		}
		void printPattern()
		{
			for(int i=0;i<string.length();i++)
			{
				{		
				for(int j=0;j<=i;j++)
					System.out.print(string.charAt(j));
				}
				System.out.print("\n");
			}
		}

	}


