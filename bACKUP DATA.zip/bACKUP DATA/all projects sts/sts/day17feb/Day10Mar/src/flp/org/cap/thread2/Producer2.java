package flp.org.cap.thread2;

import java.util.Random;

import flp.org.cap.WareHouse;

public class Producer2 implements Runnable
{
	private Warehouse wh;
	
	public Producer2(Warehouse wh){
		
		this.wh=wh;
	}
	@Override
	public void run() {
		while(true)
		{
			int x=new Random().nextInt(500);
			int num=wh.add(x);
			System.out.println("Producer:"+num);
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
		
	}

}



