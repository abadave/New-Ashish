package flp.cap.org;
import java.util.Scanner;

public class Encrypt {
	String string,tmp;
	char ch;
	int count=0;
	public void getString()
	{
		System.out.println("Enter string");
		Scanner sc=new Scanner(System.in);
		string=sc.next();
		System.out.println("Enter character");
		tmp=sc.next();
		ch=tmp.charAt(0);
	}
	public void encryptString()
	{
		
	}

}
