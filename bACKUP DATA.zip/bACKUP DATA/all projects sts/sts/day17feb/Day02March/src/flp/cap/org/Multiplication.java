package flp.cap.org;

public class Multiplication implements Runnable {

	private int num;
	
	
	public Multiplication(int num) {
		super();
		this.num = num;
	}

	public void printtable(){
		for (int i=num; i<=20; i++){
			
			int ans = i*10;
			
			System.out.println(Thread.currentThread().getName() + "-->" + i + "*" + 10 +"="+ ans );
		}
		
	}

	
	
	@Override
	public void run() {
		 
		printtable();
			
			
	
		
		
	}
	
	

}
