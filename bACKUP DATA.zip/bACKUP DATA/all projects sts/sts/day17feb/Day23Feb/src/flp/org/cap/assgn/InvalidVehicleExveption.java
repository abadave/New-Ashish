package flp.org.cap.assgn;


	public class InvalidVehicleExveption extends RuntimeException {
		
		public InvalidVehicleExveption(String arg)
		{
			
			super(arg);
			
			
			
			
		}

	}


