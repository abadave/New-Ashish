package Capgemini.flp.org;


import java.io.IOException;
	import java.io.PrintWriter;

	import javax.servlet.ServletException;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;

import java.sql.*;
	
	public class LoginServletsCust extends HttpServlet {
		private static final long serialVersionUID = 1L;

		
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
	
			
			
		
			PrintWriter out= response.getWriter();
			
			out.println("Login Page!!!<br><br>");
			
			
			String userName=request.getParameter("uname");
			String userPwd=request.getParameter("upwd");
			out.println("Username:"+ userName+ "<br>");
			out.println("Userpassword:"+ userPwd+ "<br>");
			
			
			
			if(userName.equals("tom")&&userPwd.equals("12345"))
				response.sendRedirect("pages/Success.html");
			else
				response.sendRedirect("pages/Login.html");
			
/*			
			try{  
				Class.forName("com.mysql.jdbc.Driver");  
				  
				Connection con=DriverManager.getConnection(  
				"jdbc:mysql://localhost:3306/logindatabase","root","Pass1234");  
				  
				
				  
				Statement stmt=con.createStatement();  
				  
				ResultSet rs=stmt.executeQuery("select * from login");  
				  boolean flag=false;
				while(rs.next())
				{
					if(userName.equals(rs.getString(1)) && userPwd.equals(rs.getString(2)))
					{
						response.sendRedirect("pages/Success.html");
						flag=true;
					}
				}
				if(flag==false)
					response.sendRedirect("pages/Login.html");
					
				  
				
				  
				}catch(ClassNotFoundException e){ 
					e.printStackTrace();
				}catch(SQLException e1){
					e1.printStackTrace();
				}
				
				 */
				 
				  
				}  
			
			
			
			
			
			
			
			
			
		

	}




