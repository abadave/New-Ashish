package day17feb;

public class Tringle extends Shape{

}
