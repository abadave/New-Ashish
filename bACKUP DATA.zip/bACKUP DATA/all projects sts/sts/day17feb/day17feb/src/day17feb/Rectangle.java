package day17feb;

public class Rectangle extends Shape {

}
