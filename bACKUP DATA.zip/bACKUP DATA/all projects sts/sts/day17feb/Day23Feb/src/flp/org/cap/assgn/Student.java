package flp.org.cap.assgn;

import java.util.*;

public class Student {
	
		
		int rollno;
		String name;
		
		public void getdata()
		{
			
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the rollno:");
			rollno = sc.nextInt();
			
			System.out.println("Enter the name:");
			name = sc.next();	
			
			
		}
		
		public void display()
		{
			
			System.out.println(rollno+""+name);
		}

	}


