package flp.cap.org;

public class X implements InterA{
	
	public void show()
	{
		System.out.println("Print class X");
	}

}
