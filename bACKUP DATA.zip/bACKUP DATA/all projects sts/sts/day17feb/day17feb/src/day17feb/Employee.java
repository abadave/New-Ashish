package day17feb;
import java.util.Scanner;

public abstract class Employee {
int emp_id;
String first_name, Last_name;
double salary;
Scanner scanner=new Scanner(System.in);

public void getEmployee(){
	System.out.println("Enter emp_id:-");
    emp_id=scanner.nextInt();
    
    System.out.println("Enter first name");
    first_name=scanner.next();
    
    System.out.println("Enter last name:-");
    Last_name=scanner.next();
}

public void printemployee(){
	System.out.println("The details of employee-->" + emp_id + first_name + Last_name);
}

public abstract double Calculatesalary();
	
	//System.out.println("the salary will be:-" + salary);
	


}
