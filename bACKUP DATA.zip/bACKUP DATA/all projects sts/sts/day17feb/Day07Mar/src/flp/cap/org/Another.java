package flp.cap.org;

public class Another extends Thread {
	static int i=0;
	
	
	void Printdetails(){
		
		
		synchronized (this){
		for(;i<10;i++)
		{
			System.out.println("i= "+ i);}
		}
			//System.out.print("\n");
	
			
	}
}
