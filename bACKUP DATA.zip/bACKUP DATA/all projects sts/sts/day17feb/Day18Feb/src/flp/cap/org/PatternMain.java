package flp.cap.org;

public class PatternMain {
	public static void main(String[] args) {
		Pattern p=new Pattern();
		p.getString();
		p.printPattern();
	}

}



