package org.capstore.domain;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class sub_category {
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((category == null) ? 0 : category.hashCode());
		result = prime * result + sub_category_id;
		result = prime * result + ((sub_category_name == null) ? 0 : sub_category_name.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		sub_category other = (sub_category) obj;
		if (category == null) {
			if (other.category != null)
				return false;
		} else if (!category.equals(other.category))
			return false;
		if (sub_category_id != other.sub_category_id)
			return false;
		if (sub_category_name == null) {
			if (other.sub_category_name != null)
				return false;
		} else if (!sub_category_name.equals(other.sub_category_name))
			return false;
		return true;
	}

	@Id
private int sub_category_id;
private String sub_category_name;



@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
@JoinColumn(name="category_id_FK")
private Category category;

public sub_category(){}
public sub_category(int sub_category_id, String sub_category_name, Category category) {
	super();
	this.sub_category_id = sub_category_id;
	this.sub_category_name = sub_category_name;
	this.category = category;
}

public int getSub_category_id() {
	return sub_category_id;
}

public void setSub_category_id(int sub_category_id) {
	this.sub_category_id = sub_category_id;
}

public String getSub_category_name() {
	return sub_category_name;
}

public void setSub_category_name(String sub_category_name) {
	this.sub_category_name = sub_category_name;
}

public Category getCategory() {
	return category;
}

public void setCategory(Category category) {
	this.category = category;
}

@Override
public String toString() {
	return "sub_category [sub_category_id=" + sub_category_id + ", sub_category_name=" + sub_category_name
			+ ", category=" + category + "]";
}


}