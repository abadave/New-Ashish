package flp.cap.org;

import java.util.Date;

public class Customer {

	private int custId;
	private String custName;
	private long regFees;
	private Date regDate;
	private String address;
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", regFees=" + regFees + ", regDate="
				+ regDate + ", address=" + address + "]";
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public long getRegFees() {
		return regFees;
	}
	public void setRegFees(long regFees) {
		this.regFees = regFees;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Customer()
	{
		
	}
	
	

}
