package flp.org.cap.assgn;

public class Splender {
	
		
		public static boolean isValidNo(String str)
		{
			
			return str.matches("[a-z]+");
			
			
			
		}
		

		public static void main(String[] args) {
			
	    int i;
	    boolean flag=false;
	    Splender D = new Splender();
		int sum=0;
			if(args.length>0)
			{
				
				for(i=0;i<args.length;i++)
				{
					
				
					try{
				    flag = Splender.isValidNo(args[i]);
				    
				    if(flag==true)
				    {
				    	throw  new ExcepCommnd ("Invalid valid number you have entered character");
				    }
				    else
				    {
				    	int p = Integer.parseInt(args[0]);
				    	int q = Integer.parseInt(args[1]);
				    	System.out.println(p+q);
				    	
				    }
				   
					}
					catch(ExcepCommnd  ex)
					{
						
						System.out.println(ex.getMessage());
					}
					
				}
				
				
			}
			
			
		}
			
			
			
		}
