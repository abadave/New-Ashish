package flp.cap.org;
import java.util.Scanner;
public class Book {
	
	int book_id, price;
	String book_name, author, publisher;
	public Book book;

	
	public Book getbookdetails() {
		Scanner sc= new Scanner(System.in);
		
	System.out.println("Enter the book id");
	book_id=sc.nextInt();
	
	System.out.println("Enter the book name");
	book_name=sc.next();
	
	System.out.println("Enter the Author Name");
	author=sc.next();
	
	System.out.println("Enter the name of publisher");
	publisher=sc.next();
        
	return book;
	}

    public void showbookdetails(){
    	
    	System.out.println(book_id+ "\t" + book_name+ "\t" + author+ "\t" +publisher+ "\t" +price);
    	
    }
}
