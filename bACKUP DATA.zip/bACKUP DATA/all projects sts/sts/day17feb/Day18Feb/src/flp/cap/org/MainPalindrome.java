package flp.cap.org;

public class MainPalindrome {

	public static void main(String[] args) {
		
		
			Palindrome p=new Palindrome();
			p.getString();
			p.checkPalindrome();
		}

	


	

}
