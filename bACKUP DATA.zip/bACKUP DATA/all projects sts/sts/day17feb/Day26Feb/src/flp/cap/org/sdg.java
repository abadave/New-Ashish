package flp.cap.org;

import java.util.ArrayList;
import java.util.ListIterator;

public class sdg {
	
	
	 public static void main(String args[]){   
	  ArrayList<String> al=new ArrayList<String>();   
  al.add("Ravi");   
  al.add("Amit");   
  al.add("Vijay");   
  al.add("Kumar");   
  al.add("Sachin");   
   
	/*for(String obj:al)   
	    System.out.println(obj);*/
  
	ListIterator<String> itr=al.listIterator();
	
	System.out.println("traversing elements in backward direction...");   
	
	while(itr.hasPrevious()){   
		
	System.out.println(itr.next());   
	
	
	}   
}   

 
	}  



