package flp.org.cap.assgn;

public class InvalidException extends Exception {
	
	
	
	public InvalidException(String arg)
	{
		
		super(arg);
		
	}
	

}
