package flp.cap.org;

import java.util.Date;

public class Account {
	
	private int acc_id;
	private String acc_name;
	private String open_date;
	private String acc_type;
	private int opening_bal;

	public Account(){}

	public Account(int acc_id, String acc_name, String open_date, String acc_type, int opening_bal) {
		super();
		this.acc_id = acc_id;
		this.acc_name = acc_name;
		this.open_date = open_date;
		this.acc_type = acc_type;
		this.opening_bal = opening_bal;
	}

	public int getAcc_id() {
		return acc_id;
	}

	public void setAcc_id(int acc_id) {
		this.acc_id = acc_id;
	}

	public String getAcc_name() {
		return acc_name;
	}

	public void setAcc_name(String acc_name) {
		this.acc_name = acc_name;
	}

	public String getOpen_date() {
		return open_date;
	}

	public void setOpen_date(String open_date2) {
		this.open_date = open_date2;
	}

	public String getAcc_type() {
		return acc_type;
	}

	public void setAcc_type(String acc_type) {
		this.acc_type = acc_type;
	}

	public int getOpening_bal() {
		return opening_bal;
	}

	public void setOpening_bal(int opening_bal) {
		this.opening_bal = opening_bal;
	}

	@Override
	public String toString() {
		return "Account [acc_id=" + acc_id + ", acc_name=" + acc_name + ", open_date=" + open_date + ", acc_type="
				+ acc_type + ", opening_bal=" + opening_bal + "]";
	}
	
	
	
}
