package Flp.org.cap;

public class ObjectEmp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
