package com.flp.fms.view;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.util.Validate;
import com.flp.fms.domain.Actor;

public class UserInteraction {
	Scanner sc=new Scanner(System.in);
	
	public Film addFilm(List<Language> languages,List<Category> category, Set<Actor> actors) {

	
	//Return fully qualified film object
	
		Film film=new Film();
		
		//Get Film Title and validate it
		
		boolean flag=true;
		String title=null;
		
		do{
		System.out.println("Enter Film Title");
		title=sc.nextLine();
		flag=Validate.isValidTitle(title);
			if(!flag)
				System.out.println("Invalid Title. Please Enter Valid Title!");
		}while(!flag);
		film.setTitle(title);
		
		
		
		// Get the description of film (no validation)
		String description= null;
		System.out.println("Enter the film description");
		description=sc.next();
		film.setDescription(description);
		
		
		//Get Release year and Validate it
		String releaseDate;
		boolean date_flag=false;
		Date release_Date=null;
		do{
			
			do{
				System.out.println("Enter Release Date:");
				releaseDate=sc.next();
				flag=Validate.isValidDate(releaseDate);
				if(!flag)
					System.out.println("Please enter date in this Format(dd-MMM-yyyy)!");
			}while(!flag);
			
			Date today=new Date();
			release_Date=new Date(releaseDate);
			if(release_Date.before(today)|| release_Date.equals(today))
				date_flag=true;
		
			if(!date_flag)
				System.out.println("Invalid Date! Date should be current date or Past Date!");
		}while(!date_flag);
		film.setReleaseYear(release_Date);
		
		
		
		
		//Rental Duration
		
		String rentalDuration;
		boolean date__flag=false;
		Date rental_Duration=null;
		do{
			
			do{
				System.out.println("Enter rental Duration:");
				rentalDuration=sc.next();
				flag=Validate.isValidRental(rentalDuration);
				if(!flag)
					System.out.println("Please enter date in this Format(dd-MMM-yyyy)!");
			}while(!flag);
			
			Date today1=new Date();
			rental_Duration=new Date(rentalDuration);
			if(/*rental_Duration.after(today1)||*/rental_Duration.equals(today1)||rental_Duration.after(release_Date))
				date__flag=true;
		
			if(!date__flag)
				System.out.println("Invalid Date! Date should be current date or future Date!");
		}while(!date__flag);
		film.setRentalDuration(rental_Duration);
		 
		
		// Get the length of Film in minutes also with validation
		
		int length;
		
		do{
			System.out.println("Enter Film Length in minutes");
			length=sc.nextInt();
			flag=Validate.isValidLength(length);
				if(!flag)
					System.out.println("Invalid Length. Please Enter Valid Film Length!");
			}while(!flag);
			film.setLength(length);
			
			// Get the film ratings and validate it
			
		int ratings;	
			do{
				System.out.println("Enter Film ratings");
				ratings=sc.nextInt();
				flag=Validate.isValidRatings(ratings);
					if(!flag)
						System.out.println("Invalid Ratings. Please Enter Valid Film Ratings");
				}while(!flag);
				film.setRatings(ratings);
	
		
				String specialFeature= null;
				System.out.println("Enter the special features");
				specialFeature=sc.next();
				film.setSpecialFeatures(specialFeature);
				
				
			//Get the Replacement cost (no validation)
			double replacementCost;
				do{
					System.out.println("Enter replacement cost");
					replacementCost=sc.nextDouble();
					flag=Validate.isValidreplacementCost(replacementCost);
						if(!flag)
							System.out.println("Invalid replacementCost. Please Enter Valid Film replacementCost");
					}while(!flag);
					film.setReplacementCost(replacementCost);
					

					//Choose Original Film Language
					System.out.println("Choose Original Language");
					Language language= addLanguage(languages);
					System.out.print(language);
					film.setOriginallanguage(language);
					
					
					//Adding all languages
					List<Language> languages2=new ArrayList<>();
					String choice;
					boolean flag_langs;
					do{
						System.out.println("Choose All Languages for the Film:");
						Language language1= addLanguage(languages);
						
						
						flag_langs=Validate.checkDuplicateLanguage(languages2, language1);
						if(!flag_langs)
							languages2.add(language1);
						else
							System.out.println("Language already Exists. Please try other languages!");
						
						
						System.out.println("Wish to add More Languages?[y|n]");
						choice=sc.next();
					}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
					film.setLanguage(languages2);
					
					
					//Accepting Film category
					
					Category cat= addcategory(category);
					film.setCategory(cat);
					
					
					//Adding all Actors
					
			
					Set<Actor>actor2=new HashSet<>();
					do{
						System.out.println("Choose All Actors for the Film:");
						Actor actor=addActor(actors);
						actor2.add(actor);
						
						System.out.println("Wish to add More Actors?[y|n]");
						choice=sc.next();
					}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
					film.setActors(actor2);
					return film;
				}
				
				
				//Choose Valid Language Object from the list of Languages
				public Language addLanguage(List<Language>  languages){
					
					Language sel_language=null;
					boolean flag;
					do{	
						//Print Langauge Details with id
						for(Language language:languages)
							System.out.println(language.getLanguage_Id() + "\t" + language.getLanguage_Name());
						
						System.out.println("Choose the Language:");
						int option=sc.nextInt();
						
						flag=false;
						
						//Check the Language Object
						for(Language language: languages)
						{
							if(option==language.getLanguage_Id())
							{
								sel_language=language;
								flag=true;
								break;
							}
						}
						
						//Print Error Message
						if(!flag)
							System.out.println("Please select valid Language Id");
					}while(!flag);	
					
					return sel_language;
			}
						
				
				
		// get and evaluate category		
				
	public Category addcategory(List<Category>  category){
					
		Category sel_category=null;
					boolean flag;
					do{	
						//Print category Details
						for(Category category1:category)
							System.out.println(category1.getCategoryId() + "\t" + category1.getName());
						
						System.out.println("Choose the Category:");
						int option=sc.nextInt();
						
						flag=false;
						
						//Check the category Object
						for(Category category1: category)
						{
							if(option==category1.getCategoryId())
							{
								sel_category=category1;
								flag=true;
								break;
							}
						}
						
						//Print Error Message
						if(!flag)
							System.out.println("Please select valid Language Id");
					}while(!flag);	
					
					return sel_category;
					
					
					//Choose Valid Actor Object from the list of Actors
	}	
					
					public Actor addActor(Set<Actor> actors){
						
						Actor sel_actor=null;
						boolean flag=false;
						// print Actor details
						do{	
						for(Actor actor:actors)
							System.out.println(actor.getAcorId() + "\t" + actor.getFirstName() + "\t" + actor.getLastName());
						
						System.out.println("Choose the Actor:");
						int option=sc.nextInt();
						
						flag=false;
						
						//Check the Actor Object
						for(Actor actor: actors)
						{
							if(option==actor.getAcorId())
							{
								sel_actor=actor;
								flag=true;
								break;
							}
						}
							
						
						//Print Error Message
						if(!flag)
							System.out.println("Please select valid Actor Id");
						}while(!flag);	
						
						return sel_actor;
					}		
					
					
				
					public void getAllFilm(Collection<Film> lst) {
						
						for(Film film:lst){
							String languages="";
							for(Language language:film.getLanguage())
								languages=languages+language.getLanguage_Name()+",";
							
							System.out.println(film.getFilmId() + "\t" +
									film.getTitle() + "\t"+
									film.getReleaseYear() + "\t"+
									film.getRentalDuration()+"\t"+
									film.getReplacementCost()+"\t"+
									film.getRatings()+"\t"+languages);
							}
						
					}
					
					// Here we searching film by ID, Name and rating
					public void searchfilm(Collection<Film> Film_lst1){
						Boolean flag=false;
						int option;
						String choice;
						
						do{
						System.out.println("1. Search By FilmId");
						System.out.println("2. Search By Film name");
						System.out.println("3. Search By Film rating");
						option=sc.nextInt();
						
						// search by film id 
							if(option==1)	
							{int id;
							System.out.println("Enter the film id, that you wish to search");
							id=sc.nextInt();
							for(Film film:Film_lst1)
							{
								if (id==film.getFilmId())
								{
									System.out.println("Film is present");
									System.out.print(film);
									flag=true;
									break;

								}
							}
								
						if(flag==false)
							System.out.println("Film does exists");
						
							}
							// search by rating
							
							if(option==3)	
							{
								System.out.println("Enter of what rating films are need to be search:");
								int rating=sc.nextInt();
						
								for(Film film:Film_lst1)
								{
									if(rating==film.getRatings())
									{
										//System.out.println("Film is exists");
										System.out.println(film);
										/*flag=true;
										break;*/
									}
								}
								if(flag==false)
									System.out.println("film not exists");
							}
							
							
							// search by film name
							if(option==2)
							{
								String FName;
								System.out.println("Enter the film name, that you wish to search");
								FName=sc.next();
								
								for(Film film:Film_lst1)
								{
									if (FName.equals(film.getTitle()))
									{
										System.out.println("Film is present");
										System.out.print(film);
										flag=true;
										break;

									}
								}
									
							if(flag==false)
								System.out.println("Film does exists");
							
							}
						System.out.println("Wish to continus:");
						choice=sc.next();
			
			}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
						
					}
					
					
					/*
					
					/// remove film
						public void removefilm(Collection<Film> Film_lst2){
							Boolean flag=false;
							int option1;
							String choice;
							
							do{
							System.out.println("1. Remove By FilmId");
							System.out.println("2. Remove By Film name");
							System.out.println("3. Remove By Film rating");
							option1=sc.nextInt();
							
					// remove by film id 
								if(option1==1)	
								{int id1;
								System.out.println("Enter the film id, that you wish to Remove");
								id1=sc.nextInt();
								for(Film film:Film_lst2)
									{
										if (id1==film.getFilmId())
										{
											Film_lst2.remove(film);
											System.out.println("Removal is Done");
										    System.out.print(film);
											flag=true;
											break;
	
										}
						
									}
								
								if(flag==false)
									System.out.println("Id not present");
						
								   }
								
								
								// Remove film by title
								if(option1==2)
								{
									String FName;
									System.out.println("Enter the film name, that you wish to remove");
									FName=sc.next();
									
									for(Film film:Film_lst2)
									{
										if (FName.equals(film.getTitle()))
										{
											Film_lst2.remove(film);
											System.out.println("Film is removed");
											System.out.print(film);
											flag=true;
											break;

										}
									}
										
								if(flag==false)
									System.out.println("Film does exists");
								
								}
								
									
								// Remove film by rating
								
								if(option1==3)
									System.out.println("Enter of what rating films are need to be remove:");
								int rating=sc.nextInt();
						
								if(!(Film_lst2.isEmpty()))
								{
					
								for(Film film:Film_lst2)
								{
									if(rating==film.getRatings())
									{
										
										Film_lst2.remove(film);
										
									}
								
								}
								
								}
								else 
									System.out.println("list is empty");
							//}
							
			
								
								System.out.println("Wish to continus:");
								choice=sc.next();
								

}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
}
						*/
						
						
						
						
						
							// updation code
						public int readFilmId() {
							System.out.println("Enter the Film ID that you wish to update:");
								return sc.nextInt();
							}



						public void deleteFilmById(Map<Integer, Film> allFilms, int filmId) {
							
							allFilms.remove(filmId);
							
						}
							
						
						public void deleteFilmByTitle(Map<Integer, Film> allFilms, String filmTitle) {
							int id;
							Set<Integer> keys=allFilms.keySet();
							Iterator<Integer> itr=keys.iterator();
							while(itr.hasNext()){
								{
									Integer key=itr.next();
									if(filmTitle.equals(allFilms.get(key).getTitle()))
									{
									id=	allFilms.get(key).getFilmId();
									allFilms.remove(id);
									System.out.println("Object deleted successfully!!");
									}
									else
										System.out.println("Title not match!!");
								}
									
							
						}
							
						}







					//	@SuppressWarnings("unchecked")
						public void deleteFilmByRatings(Map<Integer, Film> allFilms, int rating) {
					
							
							
							Collection<Film>fildel=allFilms.values();
							Iterator<Film> itr =  fildel.iterator();
							List<Integer> selectedFilmIds = new ArrayList();
							

							while(itr.hasNext()){
								
								Film film = itr.next();
								
								if(film.getRatings() == rating){
									
									selectedFilmIds.add(film.getFilmId());	
								}
							}
							

							for(Integer filmId : selectedFilmIds){
								
								allFilms.remove(filmId);
							}
							
							
						}

						}


