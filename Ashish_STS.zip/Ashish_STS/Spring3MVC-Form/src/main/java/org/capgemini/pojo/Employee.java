package org.capgemini.pojo;

import java.util.Date;

import javax.validation.constraints.Future;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

public class Employee {
	
	private int empId;
	
	@NotEmpty(message="* Please enter FirstName.")
	private String firstName;
	private String lastName;
	
	@NotEmpty(message="* Please enter Email.")
	@Email(message="* Please enter valid email.")
	private String emailId;
	
	@Range(min=2000,max=200000,message="* Salary should be between 2000 to 2laks.")
	private double salary;
	
	@Min(value=18,message="* Age should be greater than 18.")
	private int age;
	
	@Past(message="* Employee DOB must be past date.")
	private Date empDob;
	
	@Future(message="* Employee DOJ must be Future date.")
	private Date empDoj;
	
	@Length(min=6,max=12,message="* Password should be 6 to 12 chars.")
	private String empPassword;
	private String department;
	
	public Employee(){}
	public Employee(int empId, String firstName, String lastName, String emailId, double salary, int age, Date empDob,
			Date empDoj, String empPassword, String department) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.salary = salary;
		this.age = age;
		this.empDob = empDob;
		this.empDoj = empDoj;
		this.empPassword = empPassword;
		this.department = department;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Date getEmpDob() {
		return empDob;
	}
	public void setEmpDob(Date empDob) {
		this.empDob = empDob;
	}
	public Date getEmpDoj() {
		return empDoj;
	}
	public void setEmpDoj(Date empDoj) {
		this.empDoj = empDoj;
	}
	public String getEmpPassword() {
		return empPassword;
	}
	public void setEmpPassword(String empPassword) {
		this.empPassword = empPassword;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName + ", emailId="
				+ emailId + ", salary=" + salary + ", age=" + age + ", empDob=" + empDob + ", empDoj=" + empDoj
				+ ", empPassword=" + empPassword + ", department=" + department + "]";
	}
	
	
	

}
