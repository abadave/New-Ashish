package org.capstore.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Chat 
{

	
	@Id
	 int chat_id ;
	  String sender_mail_id ;
	  String receiver_mail_id ;
	  String message;
	  Date chat_date ;
	  
	  
	  
	  Chat(){}
	  
	  
	public int getChat_id() {
		return chat_id;
	}
	public void setChat_id(int chat_id) {
		this.chat_id = chat_id;
	}
	public String getSender_mail_id() {
		return sender_mail_id;
	}
	public void setSender_mail_id(String sender_mail_id) {
		this.sender_mail_id = sender_mail_id;
	}
	public String getReceiver_mail_id() {
		return receiver_mail_id;
	}
	public void setReceiver_mail_id(String receiver_mail_id) {
		this.receiver_mail_id = receiver_mail_id;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Date getChat_date() {
		return chat_date;
	}
	public void setChat_date(Date chat_date) {
		this.chat_date = chat_date;
	}
	public Chat(int chat_id, String sender_mail_id, String receiver_mail_id, String message, Date chat_date) {
		super();
		this.chat_id = chat_id;
		this.sender_mail_id = sender_mail_id;
		this.receiver_mail_id = receiver_mail_id;
		this.message = message;
		this.chat_date = chat_date;
	}
	@Override
	public String toString() {
		return "Chat [chat_id=" + chat_id + ", sender_mail_id=" + sender_mail_id + ", receiver_mail_id="
				+ receiver_mail_id + ", message=" + message + ", chat_date=" + chat_date + "]";
	}
	  
	  
	  
	  
	  
}
