package org.capstore.service;

import java.util.List;

import org.capstore.dao.Discount_Dao;
import org.capstore.dao.Discount_DaoImpl;
import org.capstore.pojo.Discount;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;

@Controller("discountService")
public class Discount_ServiceImpl implements Discount_Service{

	@Autowired
	Discount_DaoImpl discountDao;
	
	@Transactional
	public void saveDiscount(Discount discount) {
		discountDao.saveDiscount(discount);
		
	}

	@Transactional
	public List<Discount> getAllDiscounts() {
		return discountDao.getAllDiscounts();
	}

	@Transactional
	public void deleteDiscount(Integer d_id) {
		discountDao.deleteDiscount(d_id);
		
	}

}
