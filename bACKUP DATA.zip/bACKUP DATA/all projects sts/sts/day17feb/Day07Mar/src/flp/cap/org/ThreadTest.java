package flp.cap.org;

public class ThreadTest {

	public static void main(String[] args) {

    MyThread mt1=new MyThread ();
    MyThread mt2=new MyThread();
	MyThread mt3=new MyThread();
	MyThread mt4=new MyThread();
	MyThread mt5=new MyThread();
	
	mt1.start();
	try{
		mt1.join();
	}catch(InterruptedException e){
		e.printStackTrace();
	}
	mt2.start();
	try{
		mt2.join();
	}catch(InterruptedException e){
		e.printStackTrace();
	}
	mt3.start();
	try{
		mt3.join();
	}catch(InterruptedException e){
		e.printStackTrace();
	}
	mt4.start();
	try{
		mt4.join();
	}catch(InterruptedException e){
		e.printStackTrace();
	}
	mt5.start();
	try{
		mt5.join();
	}catch(InterruptedException e){
		e.printStackTrace();
	}
}
}



