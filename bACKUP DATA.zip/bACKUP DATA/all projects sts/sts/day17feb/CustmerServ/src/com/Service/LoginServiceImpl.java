package com.Service;

import com.dao.LoginDao;
import com.dao.LoginDaoImpl;
import com.pojo.Customer;
import com.pojo.LoginUser;

public class LoginServiceImpl implements LoginService {
	
	
	private LoginDao loginDao=new LoginDaoImpl();

	@Override
	public boolean isValidLogin(LoginUser loginUser) {
		
		/*boolean flag=false;
		
		if(loginUser.getUserName().equals("tom") && 
				loginUser.getUserPwd().equals("12345"))
			flag=true;
		*/
		return loginDao.isValidLogin(loginUser);
	}

	@Override
	public void saveCustomer(Customer customer) {
		loginDao.saveCustomer(customer);
	}

}

