package com.flp.fms.junit;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

public class FilmTest {
	

	IFilmService filmService=new FilmServiceImpl();
   
	//TEST CASES FOR  FILM
	//1.Film object should not be null
	//2. Valid Film object to add
	//3.Film not present to search
	//4.Film not present to delete
	
	
	
/*
	
	@Test
	public void filmObjectIsNullWhenSearchById()
	{
		 Film film=null;
        assertNotEquals(film, filmService.getSearchFilmByID(1));
	}
*/
	@Test
	public void isValidFilmEntryToAdd()
	{
		
		
		 Film film=new Film();
		 film.setFilmId(74);
		 film.setTitle("Three Idiots");
		 film.setDescription("good");
		 
		 String date="29-may-2007";
		 Date dt=new Date(date);
		 film.setReleaseYear(dt);
		 
		
		 Language lang=new Language();
			 lang.setLanguage_Id(1);
		 film.setOriginallanguage(lang);
		 
		 String date1="19-may-2007";
		 Date dt1=new Date(date1);
		 film.setRentalDuration(dt1);
		 
		 film.setLength(50);
		 
		 film.setReplacementCost(200);
		 
		 film.setRatings(2);
		 
		 film.setSpecialFeatures("very nice");
		 
		 Category cat1=new Category();
	     cat1.setCategoryId(1);
		 film.setCategory(cat1);
		 
		 List<Language> langs=new ArrayList<>();
			Language lang1=new Language();
			lang1.setLanguage_Id(2);
			langs.add(lang);
	    	langs.add(lang1);
			film.setLanguage(langs);
			
			Set<Actor> actors=new HashSet<>();
			Actor actor1=new Actor();
			actor1.setActorId(1);
			Actor actor2=new Actor();
	    	actor2.setActorId(2);
			actors.add(actor1);
			actors.add(actor2);
	    	film.setActors(actors);
		
		
        assertEquals(1, filmService.addFilm(film));
	}
	

	
	@Test
	public void isFilmNotPresent()
	{
		 List<Film> films=filmService.getAllFilms();
		 Film film1=new Film();
		 for(Film film:films)
			 film1=film;
        assertNotEquals(film1, filmService.searchFilm(film1));
	}
	
	@Test
	public void isFilmNotPresentToDelete()
	{
		
		 assertFalse(filmService.deleteFilm(50));
		
	}
	

}
