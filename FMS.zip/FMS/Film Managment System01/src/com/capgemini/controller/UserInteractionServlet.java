package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;

/**
 * Servlet implementation class UserInteractionServlet
 */
public class UserInteractionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	
		PrintWriter out=response.getWriter();
		
		// making object here
		FilmServiceImpl filmService=new FilmServiceImpl();
		IActorService actorService=new ActorServiceImpl();

		 Set<Actor> actor= actorService.getActors();
		 List<Category> category=filmService.getCategory();
			List<Language> languages=filmService.getLanguages();

				out.println("<html>");
				out.println("<head>");
				
			// adding datepicker functions	

out.print("<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>"
		+ "<script type='text/javascript' src='script/validate1.js'></script>"
		+"<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"
		+"<script src='http://code.jquery.com/jquery-1.10.2.js'></script>"
		+"<script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"
		+" <script>"
		+" $(function() {"
		+" $( '#datepicker1' ).datepicker({"
		+"dateFormat:'dd-M-yy'"
		+"});"
		+" $( '#datepicker1' ).datepicker('show');"
		+"$( '#datepicker1' ).datepicker('setDate',new Date());"
		+"});"
		+" $(function() {"
		+"$( '#datepicker2' ).datepicker({"
		+" dateFormat:'dd-M-yy'"
		+"});"
		+" $( '#datepicker2' ).datepicker('show');"
		+"$( '#datepicker2' ).datepicker('setDate',new Date());"
		+" });"
		+"</script>");

		// calling alert box function 
out.println( "<script type='text/javascript' src='script/AlertBox.js'></script>");
	
				out.println("");
				
			// creating form for add film in DB
				out.println("<title>Film Management System</title>");
				out.println("</head>");

				out.println("<body>");
				out.println("<form name='addfilm' method='post' action='AddFilm' onsubmit='return myFunction()' onsubmit='return validateForm()'>");
				
				

				out.println("<h2 style='color:white'><center>Film Registration Form</center></h2>");
				
				out.print("<table style='color:white'>");

				// adding Film Title
				out.println("<tr>"
						+"<td>FilmTitle:</td>"
						+"<td><input type='text' name='filmtitle' size='20' >"
						+"<div id='titlefms' class='errMsg'> </div>"
						+"</td>"
						+"</tr>");
					
				// film description	
				out.println("<tr>"
					+"<td>Film Description:</td>"
					+"<td>"
					+"<textarea rows='4' name='filmdescription' cols='25'></textarea>"
					+"<div id='descfms' class='errMsg'> </div> "
					+"</td>"
					+"</tr>");
					
				//List of ACTORs get displayed from Database
				
				out.print("<tr><td>Actor</td>:"
						+ "<td><select name='actor'>");
				for(Actor actor1:actor){
					out.print("<option value='"+actor1.getActorId()+"'>"+actor1.getActorId()+" "+actor1.getFirstName()+" "+actor1.getLastName()+"</option>");
				}
				out.print("</select></td></tr>");
					
				
				
					// adding release date	
				out.println("<tr>"
						+"<td>Release Date:</td>"
						+"<td>"
						+"<input type='text' id='datepicker1' name='releasedate' size='25'>"
						+"<div id='releasedatefms' class='errMsg'> </div> "
						+"</td>"
						+"</tr>");
				
				
				// adding rental duration				
					out.println("<tr>"
						+"<td>Rental Duration:</td>"
						+"<td>"
						+ "<input type='text' id='datepicker2' name='rentalduration' size='25'>"
						+"<div id='rentaldurationfms' class='errMsg'> </div> "
						+"</td>"
						+"</tr>");
				
				
				
					// adding film length in minutes
					out.println("<tr>"
					+"<td>FilmLength:</td>"
					+"<td><input type='text' name='filmlength' size='20' >"
					+"<div id='lenghtfms' class='errMsg'> </div>"
					+"</td>"
					
					+"</tr>"
					+"<tr>");
					
					// adding replacement cost
					out.println("<tr>"
					+"<td>Replacement Cost:</td>"
					+"<td><input type='text' name='replacementcost' size='20'>"
					+"<div id='replacementcostfms' class='errMsg'> </div>"
					+"</td>"
					
					+"</tr>"
					+"<tr>");
					
					// adding special feature
					out.println("<tr>"
					+"<td>Special Features:</td>"
					+"<td>"
						+"<textarea rows='4' name='specialfeature' cols='25'></textarea>"
					+"</td>"
					+"</tr>");

					
					
					
					
                    //Category get displayed using database
					
					out.println("<tr><td>Category</td><td>:</td>" + "<td><select name='category'>");
					for(Category cat1:category){
						out.print("<option value='"+cat1.getCategoryId()+"'>"+cat1.getCategoryId()+" "+cat1.getName()+"</option>");
					}
					out.print("</select></td></tr>");					
						
                    
					//Original Language get displayed using database
					
					out.println("<tr><td>Original Language</td><td>:</td>" + "<td><select name='orglanguage'>");
					for(Language lang1:languages){
						out.print("<option value='"+lang1.getLanguage_Id()+"'>"+lang1.getLanguage_Id()+" "+lang1.getLanguage_Name()+"</option>");
					}
					out.print("</select></td></tr>");
					
					
					
					//Other Languages get displayed using database
					
					out.println("<tr><td>Other Languages</td><td>:</td>" + "<td><select name='othrlanguage'>");
					for(Language lang1:languages){
						out.print("<option value='"+lang1.getLanguage_Id()+"'>"+lang1.getLanguage_Id()+" "+lang1.getLanguage_Name()+"</option>");
					}
					out.print("</select></td></tr>");			
					
					
					// rating get displayed on form
					out.println("<tr>"
							+"<td>Film Rating:</td>"
							+"<td>"
							+"<select name='rating'>"
								+"<option value='1'>1</option>"
								+"<option value='2'>2</option>"
								+"<option value='3'>3</option>"
								+"<option value='4'>4</option>"
								+"<option value='5'>5</option>"
							+"</select>"
							
							+"</td>"
						+"</tr>");
					
					// saving all the input data
					out.println("<tr>"
						+"<td></td>"
						+"<td><input type='submit' value='Save'>"
						+"<input type='reset' value='Clear'>"
						 +"</td>"
					+"</tr>");

					
					response.setContentType("text/html");  
					out.println("<script type=\"text/javascript\">");  
					
					out.println("</script>");   
					    
		        	out.println("</table>");


				out.println("</form>");


				out.println("</body>");
				out.println("</html>");

	}

}



















