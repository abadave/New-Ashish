package flp.cap.org;
import java.util.Scanner;

public class Employee {

	int emp_id;
	String Emp_name;
	
public Employee()
{
	
}

public Employee(int emp_id, String emp_name)
{
	
}
}


