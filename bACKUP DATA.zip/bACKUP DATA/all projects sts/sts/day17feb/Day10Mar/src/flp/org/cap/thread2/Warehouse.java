package flp.org.cap.thread2;

import java.util.Stack;

public class Warehouse {


	private Stack<Integer>stack=new Stack<Integer>();
	
	public synchronized int add(int x){
		
		if(stack.size()==10)
			try {
				wait();
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			} else {
					System.out.println(stack.push(x));
			} 
		      notify();
	          return stack.push(x);
	}
	
	public synchronized int remove(){
		if(stack.isEmpty())
		{ 
			try{
				wait();
			    }catch (InterruptedException e) {
				e.printStackTrace();
			    }}else {
			      System.out.println(stack.pop());
			    }notify();
		      return stack.pop();
		      
		
	}
		

}

