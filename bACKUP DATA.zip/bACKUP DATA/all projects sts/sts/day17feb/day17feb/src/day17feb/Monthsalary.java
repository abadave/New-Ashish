package day17feb;
import java.util.Scanner;

public class Monthsalary {

int no_day;
float salary_perday;
}
