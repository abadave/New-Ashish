package flp.cap.org;

public class CapGemInI extends Thread {

		public void Printdetails(String mystring){
			
			
			synchronized (this){
			for(int i=0;i<mystring.length();i++)
			{
				{		
				for(int j=0;j<=i;j++)
					System.out.print(mystring.charAt(j));
				}
				System.out.print("\n");
			}
	}
		}
	}
