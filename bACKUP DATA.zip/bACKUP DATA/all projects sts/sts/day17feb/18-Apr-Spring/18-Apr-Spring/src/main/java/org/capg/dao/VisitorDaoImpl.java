package org.capg.dao;

import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;


public class VisitorDaoImpl {

	private JdbcTemplate jdbcTemplate;
	private DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource=dataSource;
		jdbcTemplate=new JdbcTemplate(dataSource);
		
	}
		
	}
	
	
