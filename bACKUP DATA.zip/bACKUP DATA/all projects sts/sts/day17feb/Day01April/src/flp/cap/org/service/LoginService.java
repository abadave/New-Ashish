package flp.cap.org.service;

import flp.cap.org.pojo.LoginUser;

public interface LoginService {
	
	public boolean isValidLogin(LoginUser loginUser);

}
