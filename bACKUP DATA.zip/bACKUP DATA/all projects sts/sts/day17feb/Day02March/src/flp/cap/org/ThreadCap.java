package flp.cap.org;
import java.util.Scanner;

public class ThreadCap extends Thread {

	private String mystring;
	
	public ThreadCap(String mystring){
		this.mystring=mystring;
	}
	
	public void run(){
	for(int i=0;i<mystring.length();i++)
	{
		{		
		for(int j=0;j<=i;j++)
			System.out.print(mystring.charAt(j));
		}
		System.out.print("\n");
	
	
	}
	
	}
	
	
}
