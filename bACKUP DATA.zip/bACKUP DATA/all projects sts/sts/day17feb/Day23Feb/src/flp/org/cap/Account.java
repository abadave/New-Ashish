package flp.org.cap;
import java.util.Scanner;

public class Account {

    String acc_id;
	String acc_name;
    //date opening_date;
	String balance;
	//address Address;
	Scanner sc=new Scanner (System.in);

	public Account(){}
	
	
	public String getAcc_id() {
		return acc_id;
	}


	public void setAcc_id(String acc_id) {
		this.acc_id = acc_id;
	}


	public String getAcc_name() {
		return acc_name;
	}

	public void setAcc_name(String acc_name) {
		this.acc_name = acc_name;
	}

	
	public String getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance = balance;
	}

	public Scanner getSc() {
		return sc;
	}

	public void setSc(Scanner sc) {
		this.sc = sc;
	}
}

	

	