package flp.org.cap;

public class Consumer implements Runnable
{
	private WareHouse wh;
	
	public Consumer(WareHouse wh){
		
		this.wh=wh;
	}
	@Override
	public void run() {
		while(true)
		{
			
			
			//int x=new Random().nextInt(500);
			int num=wh.remove();
			System.out.println("Consumer:"+num);
		}
		
	}


	
}
