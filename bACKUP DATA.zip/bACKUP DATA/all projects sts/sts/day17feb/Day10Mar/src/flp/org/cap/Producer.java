package flp.org.cap;

import java.util.Random;

public class Producer implements Runnable
{
	private WareHouse wh;
	
	public Producer(WareHouse wh){
		
		this.wh=wh;
	}
	@Override
	public void run() {
		while(true)
		{
			int x=new Random().nextInt(500);
			int num=wh.add(x);
			System.out.println("Producer:"+num);
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
		
	}

	
}
