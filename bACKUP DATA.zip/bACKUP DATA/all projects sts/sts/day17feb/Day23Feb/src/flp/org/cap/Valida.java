package flp.org.cap;


	public class Valida {
		
		public static boolean isValidacc_id(String acc_id){
		return acc_id.matches("\\d{9}");
		}
		
		public static boolean isValidacc_name(String acc_name){
		return acc_name.matches("[A-Z][a-z]+");
		}
	    
		public static boolean isValidaddress(String address){
			return address.matches("[A-Z][a-z]+");
		}

	}



