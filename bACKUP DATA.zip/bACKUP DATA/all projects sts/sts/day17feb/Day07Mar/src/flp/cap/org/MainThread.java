package flp.cap.org;

public class MainThread {

	public static void main(String[] args) {
		Another asd= new Another();
		
		
		Thread t1=new Thread(){
			public void run(){
				asd.Printdetails();

	}
		};
		Thread t2=new Thread(){
			public void run(){
				asd.Printdetails();
		
		
	}
};/*
Thread t3=new Thread(){
	public void run(){
		asd.Printdetails();


}
};*/

	}

}
