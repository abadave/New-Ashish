package com.dao;

import java.util.ArrayList;

import com.pojo.Customer;
import com.pojo.LoginUser;

public interface LoginDao {

	public boolean isValidLogin(LoginUser loginUser) ;
	public void saveCustomer(Customer customer);
	public ArrayList<Customer> getAllCustomer();
		
	


}
