package flp.org.cap.assgn;

import java.util.Scanner;

public class Account {

	int accountId;
	String accountName;
	String openingDate;
	float depositAmt;
	String accountType;
	
	
	void deposit()
	{
		try
		{
			System.out.println("Enter the Account Id:");
			Scanner sc = new Scanner(System.in);
			accountId = sc.nextInt();
			
			System.out.println("Enter the Account Name:");
			accountName = sc.next();
			
			System.out.println("Enter the AccountOpening Date:");
			openingDate = sc.next();
			
			
			
			System.out.println("Enter the Account Type:");
			accountType = sc.next();
			
			
			if(accountType.equals("Current"))
			{
				
				System.out.println("Enter the Deposit Amount greater than 5000:");
				depositAmt = sc.nextFloat();
				
			}
			else if(accountType.equals("Savings"))
				
			{
				
				System.out.println("Enter the Deposit Amount greater than 1000:");
				depositAmt = sc.nextFloat();
			}
			else if(accountType.equals("Salary"))
			{
				System.out.println("Enter the Deposit Amount from 0 onwards:");
				depositAmt = sc.nextFloat();
				
			}
			if(depositAmt<1000&&accountType.equals("Savings")||depositAmt<5000&&accountType.equals("Current"))
			{
				
				throw  new InvalidException("Invalid Salary Amount");
			}
			
		}
		
		catch(InvalidException ex)
		{
			
			System.out.println(ex.getMessage());
		}
		
		
	}	
		public static void main (String args[])
		{
			Account A = new Account();
			A.deposit();
			
		}
		
	
}
