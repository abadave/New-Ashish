package com.flp.fms.domain;

public class LoginUser {
	
	// private fields
	private String userName;
	private String userPwd;
	
	// no argument constructor
	public LoginUser(){}
	
	// argument constructor
	public LoginUser(String userName, String userPwd) {
		super();
		this.userName = userName;
		this.userPwd = userPwd;
	}
	
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPwd() {
		return userPwd;
	}
	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
		
		
	}
	
	// To string method
	@Override
	public String toString() {
		return "LoginUser [userName=" + userName + ", userPwd=" + userPwd + "]";
	}
	

}
