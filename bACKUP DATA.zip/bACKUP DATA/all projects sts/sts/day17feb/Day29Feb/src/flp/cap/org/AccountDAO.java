package flp.cap.org;

public interface AccountDAO {
	

}
