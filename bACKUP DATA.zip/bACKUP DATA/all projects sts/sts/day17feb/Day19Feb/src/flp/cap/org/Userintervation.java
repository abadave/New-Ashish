package flp.cap.org;
import java.util.Scanner;
public class Userintervation {

Scanner sc=new Scanner (System.in);



public void getempldetails(){
	
	
	   EmployeeValid emp=new EmployeeValid();
		boolean flag;
		int emp_id;
		String kinid, firstname, lastname;
		String address, email, mobileno;
		
			
		System.out.println("Enter employee id");
		emp_id=sc.nextInt();
		
		do{
			
		System.out.println("Enter employee kinid");
		kinid=sc.next();
		
		flag=Valida.isValidKinid(kinid);
		if(!flag)
			System.out.println("InValid KinId. Please try Again!");
		
	}while(!flag);
		emp.setEmp_id(kinid);
		
	do {
	    System.out.println("Enter employee firstname");
		firstname=sc.next();
	
		flag=Valida.isValidfirstname(firstname);
		if(!flag)
		System.out.println("InValid firstname. Please try Again!");
			
		}while(!flag);
		emp.setFirstname(firstname);
		do{
		
		System.out.println("Enter employee lastname");
		lastname=sc.next();
		flag=Valida.isValidlastname(lastname);
		if(!flag)
		System.out.println("InValid lastname. Please try Again!");
		
    	}while(!flag);
		emp.setLastname(lastname);
	
		do{
		System.out.println("Enter employee address");
		address=sc.next();
		flag=Valida.isValidaddress(address);
		if(!flag)
		System.out.println("InValid address. Please try Again!");
			
	    }while(!flag);
		emp.setAddress(address);
		
		do{
		System.out.println("Enter employee Emailid");
		email=sc.next();
		flag=Valida.isValidemail(email);
		if(!flag)
		System.out.println("InValid email. Please try Again!");
		
    	}while(!flag);
		emp.setEmail(email);
		
		
		do{
		System.out.println("Enter employee mobileno");
		mobileno=sc.next();
		
		flag=Valida.isValidmobile(mobileno);
		if(!flag)
		System.out.println("InValid mobileno. Please try Again!");
		
    	}while(!flag);
		emp.setMobileno(mobileno);
	
		
	}
}
	
	


