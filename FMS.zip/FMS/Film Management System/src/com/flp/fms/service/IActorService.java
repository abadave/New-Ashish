package com.flp.fms.service;
import java.util.Set;

import com.flp.fms.domain.Actor;

public interface IActorService {
	// set method for actor
	public Set<Actor> getActors();
}
