package flp.org.cap.thread2;

//package flp.org.cap.thread2;

public class Consumer2 implements Runnable
{
	private Warehouse wh;
	
	public Consumer2(Warehouse wh){
		
		this.wh=wh;
	}
	@Override
	public void run() {
		while(true)
		{
			
			
			//int x=new Random().nextInt(500);
			int num=wh.remove();
			System.out.println("Consumer:"+num);
		}
		
	}


}
