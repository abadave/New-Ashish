package com.flp.fms.dao;

import java.util.HashSet;
import java.util.Set;

import com.flp.fms.domain.Actor;


public class ActorDaoImplForDB implements IActorDao{

	@Override
	public Set<Actor> getActors() {
		
		Set<Actor> actors=new HashSet<>();
		actors.add(new Actor(101,"Amitabh","Bacchan"));
		actors.add(new Actor(102,"Shahrukh","Khan"));
		actors.add(new Actor(103,"Hritik","Roshan"));
		actors.add(new Actor(104,"Abhishek","Bacchan"));
		actors.add(new Actor(105,"Amir","Khan"));
		
		
		return actors;
	
	}
}
