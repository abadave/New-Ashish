package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class AddFilm
 */
public class AddFilm extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
        // making object
		IFilmService loginService=new FilmServiceImpl();
		
		Film film=new Film();
		
		// set the data to DB
		film.setTitle(request.getParameter("filmtitle"));
		film.setDescription(request.getParameter("filmdescription"));
		film.setLength(Integer.parseInt(request.getParameter("filmlength")));
		Language lang=new Language(); 
		lang.setLanguage_Id(Integer.parseInt(request.getParameter("orglanguage")));
		film.setOriginallanguage(lang);
		// adding language 
		List<Language> languages=new ArrayList<>();
		String[] str=request.getParameterValues("othrlanguage");
		for(String str1:str){
			Language lang1=new Language(); 
			lang1.setLanguage_Id(Integer.parseInt(str1));
			languages.add(lang1);
		}
		film.setLanguage(languages);
		
		film.setRatings(Integer.parseInt(request.getParameter("rating")));
		
		
		film.setReplacementCost(Double.parseDouble(request.getParameter("replacementcost")));
		film.setReleaseYear(new Date(request.getParameter("releasedate")));
		
		film.setRentalDuration(new Date(request.getParameter("rentalduration")));
		
		film.setSpecialFeatures(request.getParameter("specialfeature"));
		
		
		// adding actor to DB 
		 Set<Actor> actors=new HashSet();
	
		String[] str3=request.getParameterValues("actor");
		for(String str1:str3){
			Actor actor1=new Actor(); 
			actor1.setActorId(Integer.parseInt(str1));
			actors.add(actor1);
		}
		film.setActors(actors);
		
		// adding category to DB 
		Category cat=new Category();
		cat.setCategoryId(Integer.parseInt(request.getParameter("category")));
		film.setCategory(cat);
		
		
	
		// calling addfilm from serviceimpl
		loginService.addFilm(film);
		// after successfully addition film, page go back to homepage
		request.getRequestDispatcher("pages/greeting.html").forward(request, response);
	}

		
		
	}

