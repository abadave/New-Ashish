package Flp.org.cap;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FormatoutDemo {

	public static void main(String[] args) {
		int empid=1001;
		String empname= "Ashish";
		double salary=10000;
		boolean isPermanent=true;
		char gender='m';
		
	File file=new File("D:\\Ashish_Apple\\badave.txt");
	FileOutputStream fout=null;
	DataOutputStream dout=null;
	try{
	fout= new FileOutputStream(file);
	dout= new DataOutputStream(fout);
	
	
	dout.writeInt(empid);
	dout.writeChar(gender);
	dout.writeDouble(salary);
	dout.writeBoolean(isPermanent);
	dout.writeChars(empname);
	
	}catch (FileNotFoundException ex){
		ex.printStackTrace();
	}
	catch (IOException ex){
	ex.printStackTrace();
	}
	}
}



