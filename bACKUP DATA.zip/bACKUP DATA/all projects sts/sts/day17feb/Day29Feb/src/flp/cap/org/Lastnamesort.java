package flp.cap.org;

import java.util.Comparator;

public class Lastnamesort  implements Comparator<EmployeeLinkHash>{

	public int compare(EmployeeLinkHash asd1, EmployeeLinkHash asd2) {
		
		if(asd1.getLastname().compareTo(asd2.getLastname())>1)
			return 1;
		else if(asd1.getLastname().compareTo(asd2.getLastname())<1)
			return -1;
		else
			return 0;
	}

	
}
