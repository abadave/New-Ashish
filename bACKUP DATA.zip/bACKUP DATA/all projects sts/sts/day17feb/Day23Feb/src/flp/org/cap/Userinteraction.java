package flp.org.cap;

import flp.org.cap.Valida;

import flp.org.cap.Account;

public class Userinteraction {
	
	public void getAccdetails(){
		
		
		   AccountValid asd=new AccountValid();
			boolean flag;
			String acc_id;
			String acc_name;
			Double balance;
				
			
			do{
				
			System.out.println("Enter accid");
			acc_id=sc.next();
			
			flag=Valida.isValidacc_id(acc_id);
			if(!flag)
				System.out.println("InValid acc_Id. Please try Again!");
			
		}while(!flag);
			asd.setacc_id(acc_id);
			
			do {
			    System.out.println("Enter acc_name");
				acc_name=sc.next();
			
				flag=Valida.isValidacc_name(acc_name);
				if(!flag)
				System.out.println("InValid acc_name. Please try Again!");
					
				}while(!flag);
				asd.setacc_name(acc_name);
				
			do {
				    System.out.println("Enter account balance");
					balance=sc.nextDouble();
				
					flag=Valida.isValidfirstname(balance);
					if(!flag)
					System.out.println("InValid balance. Please try Again!");
						
					}while(!flag);
					asd.setbalance(balance);
			
		
}
	}