package flp.cap.org;
import java.util.Scanner;

public class Occurance {
	String string,tmp;
	char ch;
	int count=0;
	public void getString()
	{
		System.out.println("Enter string");
		Scanner sc=new Scanner(System.in);
		string=sc.next();
		System.out.println("Enter character");
		tmp=sc.next();
		ch=tmp.charAt(0);
	}
	public void countCharacter()
	{
		for(int i=0;i<string.length();i++)
		{
			if(string.charAt(i)==ch)
				count++;
		}
	}
	public void printCount()
	{
		System.out.println("The count is "+count);
	}

}




