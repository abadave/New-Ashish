package flp.cap.org.dao;
import flp.cap.org.pojo.LoginUser;


public interface LoginDao {
	
	public boolean isValidLogin(LoginUser loginUser) ;
		

}
