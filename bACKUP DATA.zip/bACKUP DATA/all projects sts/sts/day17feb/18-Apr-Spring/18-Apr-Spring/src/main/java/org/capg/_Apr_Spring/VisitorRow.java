package org.capg._Apr_Spring;

import java.sql.ResultSet;
import java.sql.SQLException;

public class VisitorRow {


	public Visitor mapRow(ResultSet rs, int count) throws SQLException {
		Visitor visitor=new Visitor();
		visitor.setVisitId(rs.getInt(1));
		visitor.setVisitName(rs.getString(2));
		visitor.setAddress((Address) rs.getObject(3));
		
		return visitor;

	}

	
	
}
