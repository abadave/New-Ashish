package flp.cap.org;
import java.util.Scanner;
public class MainClassbook {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int option;
		String choice;
		
		BookDaoImp a=new BookDaoImp();
		Book book=new Book();
		Scanner sc= new Scanner(System.in);
		do{
			System.out.println("1.Save book");
			System.out.println("2.listofallbook");
			System.out.println("enter your option");
			option=sc.nextInt();
			
		if(option==1)
		{
		book.getbookdetails();
		a.savebook(book);
		
		}else if (option==2)

			a.listofallbook();
	
		System.out.println("Wish to countinue, Y/N");
		choice=sc.next();
		
		} while (choice.charAt(0)=='Y' || choice.charAt(0)=='y');
		
	}
}




