package org.capstore.controller;
import org.capstore.domain.Category;
import org.capstore.domain.Discount;
import org.capstore.domain.Images_Electronics;
import org.capstore.domain.coupon;
import org.capstore.domain.images_furnitures;
import org.capstore.domain.product;
import org.capstore.domain.sub_category;
import org.capstore.service.CategoryService;
import org.capstore.service.ProductService;

import java.util.List;
import java.util.Map;

import javax.persistence.Query;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MerchantController {

	@Autowired
	private CategoryService categoryService;



	@RequestMapping(value="/MostViewed",method=RequestMethod.GET,
			produces={"application/json"})
	public  String getAll()
	{
		/*List<Category> categories=categoryService.getAllCategories();
		map.put("categories", categories);
		System.out.println(categories);*/
		return "MostViewed";
	}

	/*@RequestMapping(value="/Uploade",method=RequestMethod.GET,
			produces={"application/json"})
	public  String getImage()
	{
		/*List<Category> categories=categoryService.getAllCategories();
		map.put("categories", categories);
		System.out.println(categories);
		return "Uploade";
	}*/

	
	
	@RequestMapping(value="/mostviewed",method=RequestMethod.GET,
			produces={"application/json"})

	public  @ResponseBody List<product> getmost()
	{
		List<product> mostviewed=categoryService.getmostVisitedFurniture();




		return mostviewed;


	}
	
	/*********************************************/
	 @RequestMapping(value="/Ascending",method=RequestMethod.GET,
			produces={"application/json"})
	public  String getAscending()
	{
		/*List<Category> categories=categoryService.getAllCategories();
		map.put("categories", categories);
		System.out.println(categories);*/
		return "Ascending";
	}

	
	
	
	@RequestMapping(value="/ascending",method=RequestMethod.GET,
			produces={"application/json"})

	public  @ResponseBody List<product> getascending()
	{
		List<product> ascending=categoryService.getAscendingPrice();




		return ascending;


	}
	 
	 
	 
	 
	 /******************************************/
	
	/*********************************************/
	 @RequestMapping(value="/ShowCoupon",method=RequestMethod.GET,
			produces={"application/json"})
	 
	 public String showAccountPage(Map<String, Object> map)
	 {
			
			map.put( "coupon", new coupon());
		/*List<Category> categories=categoryService.getAllCategories();
		map.put("categories", categories);
		System.out.println(categories);*/
		return "ShowCoupon";
	}

	
	 
	 @RequestMapping(value={"/GenerateCoupon","/updateCoupon"},method=RequestMethod.GET)
		public String showCouDetails(Map<String, Object> map,
				
				@Valid @ModelAttribute("coupon") coupon coupon, BindingResult result){
		 
			//List<Coupon> coupons= couponService.getAllCoupons();
			//map.put("cous",coupons);
			//map.put("couSearch",searchCoupon);
			System.out.println(coupon);
			/*if(result.hasErrors()){
				//System.out.println("Search Object:" + searchEmployee);
				//System.out.println(result);
				return "coupon";
			}
			else{*/
				//searchCoupon=null;
			
				
				
				return "GenerateCoupon";
			
		}
	 
	 
	 
	 
	 
	 //**********************************/
	
	
	@RequestMapping(value="/showcoupon",method=RequestMethod.GET,
			produces={"application/json"})

	public  @ResponseBody List<product> getcoupon()
	{
		List<product> showcoupon=categoryService.getCoupon();




		return showcoupon;


	}
	
	
	
	
	
	
	 
	 
	 
	 
	 /******************************************/
	
	/*********************************************/
	 @RequestMapping(value="/Rating",method=RequestMethod.GET,
			produces={"application/json"})
	public  String getRating()
	{
		/*List<Category> categories=categoryService.getAllCategories();
		map.put("categories", categories);
		System.out.println(categories);*/
		return "Rating";
	}

	
	
	
	@RequestMapping(value="/rating",method=RequestMethod.GET,
			produces={"application/json"})

	public  @ResponseBody List<product> getrating()
	{
		List<product> rating=categoryService.getRating();




		return rating;


	}
	 
	 
	 
	 
	 /******************************************/
	
	/*********************************************/
	 @RequestMapping(value="/Descending",method=RequestMethod.GET,
			produces={"application/json"})
	public  String getDescending()
	{
		/*List<Category> categories=categoryService.getAllCategories();
		map.put("categories", categories);
		System.out.println(categories);*/
		return "Descending";
	}

	
	
	
	@RequestMapping(value="/descending",method=RequestMethod.GET,
			produces={"application/json"})

	public  @ResponseBody List<product> getdesc()
	{
		List<product> descending=categoryService.getDescendingPrice();




		return descending;


	}
	 
	 
	 
	 
	 /******************************************/

	/*
	@RequestMapping("/HomePage")
	public @ResponseBody ModelAndView showCategories()
{
		return new ModelAndView ("HomePage","msg", "List Of categories");

}*/


	//@RequestMapping(value="/HomePage",method=RequestMethod.GET)
	//
	//	public @ResponseBody ModelAndView showSubCategories()
	//{
	//		return new ModelAndView ("HomePage","msg1","List of subcategories");
	//}
	//	


	@RequestMapping(value="/HomePage",method=RequestMethod.GET,
			produces={"application/json"})
	public  String getAllCategories()
	{
		/*List<Category> categories=categoryService.getAllCategories();
		map.put("categories", categories);
		System.out.println(categories);*/
		return "HomePage";
	}

	
	/*@RequestMapping(value="/view",method=RequestMethod.GET,
			produces={"application/json"})
	public  String getAll()
	{
		/*List<Category> categories=categoryService.getAllCategories();
		map.put("categories", categories);
		System.out.println(categories);
		return "view";
	}*/


	@RequestMapping(value="/Furniture",method=RequestMethod.GET,
			produces={"application/json"})
	public  String getAllFurniture()
	{
		/*List<Category> categories=categoryService.getAllCategories();
		map.put("categories", categories);
		System.out.println(categories);*/
		return "Furniture";
	}



	/*@RequestMapping(value="/MostViewed",method=RequestMethod.GET,
			produces={"application/json"})

	public  String getmostViewedFurniture()
	{
		List<Category> categories=categoryService.getAllCategories();
		map.put("categories", categories);
		System.out.println(categories);
		return "mostviewed";
	}
*/



	@RequestMapping(value="/Kitchenware",method=RequestMethod.GET,
			produces={"application/json"})

	public  String getAllKitchen()
	{
		/*List<Category> categories=categoryService.getAllCategories();
		map.put("categories", categories);
		System.out.println(categories);*/
		return "Kitchenware";
	}


	
	
	/*@RequestMapping(value="/GenerateCoupon",method=RequestMethod.GET,
			produces={"application/json"})

	public  String generateCoupon()
	{
		/*List<Category> categories=categoryService.getAllCategories();
		map.put("categories", categories);
		System.out.println(categories);
		return "GenerateCoupon";
	}*/
	
	

	@RequestMapping(value="/HomeAppliance",method=RequestMethod.GET,
			produces={"application/json"})

	public  String getAllHome()
	{
		/*List<Category> categories=categoryService.getAllCategories();
		map.put("categories", categories);
		System.out.println(categories);*/
		return "HomeAppliance";
	}
	
	
	@RequestMapping(value="/Chat",method=RequestMethod.GET,
			produces={"application/json"})

	public  String getAllChat()
	{
		/*List<Category> categories=categoryService.getAllCategories();
		map.put("categories", categories);
		System.out.println(categories);*/
		return "Chat";
	}
	
	
	
	

	/*@RequestMapping(value="/mostviewed",method=RequestMethod.GET,
			produces={"application/json"})

	public  String getAllFurView()
	{
		/*List<Category> categories=categoryService.getAllCategories();
		map.put("categories", categories);
		System.out.println(categories);
		return "mostviewed";
	}

	
	
	@RequestMapping(value="/view",method=RequestMethod.GET,
			produces={"application/json"})
	public  @ResponseBody List<product> getview()
	{
		List<product> view=categoryService.getmostVisitedFurniture();

		return view;
	}*/
	
	
	
	

	@RequestMapping(value="/categories",method=RequestMethod.GET,
			produces={"application/json"})
	public  @ResponseBody List<Category> getCategories()
	{
		List<Category> categories=categoryService.getAllCategories();

		return categories;
	}


	


	@RequestMapping(value="/furnitures",method=RequestMethod.GET,
			produces={"application/json"})

	public  @ResponseBody List<product> getFurniture()
	{
		List<product> furnitures=categoryService.getAllFurniture();




		return furnitures;


	}



	@RequestMapping(value="/kitchen",method=RequestMethod.GET,
			produces={"application/json"})

	public  @ResponseBody List<product> getKitchen()
	{
		List<product> kitchen=categoryService.getAllKitchen();




		return kitchen;


	}


	@RequestMapping(value="/home",method=RequestMethod.GET,
			produces={"application/json"})

	public  @ResponseBody List<product> getHome()
	{
		List<product> home=categoryService.getAllHome();




		return home;


	}





	@RequestMapping(value="/subcategories",method=RequestMethod.GET,

			produces={"application/json"})

	public @ResponseBody List<sub_category> getAllSubCategories()
	{
		List<sub_category> subcategories=categoryService.getsubcategory1();
		System.out.println(subcategories);

		return subcategories;
	}



//**** Save Coupon****/
	
	@RequestMapping(value="/saveCoupon",method=RequestMethod.POST)
	public ModelAndView saveAccount(@Valid @ModelAttribute("coupon") coupon coupon,
			BindingResult result)
	//public String addCoupon(@ModelAttribute("coupon") coupon coupon)
	{
		
		if(!result.hasErrors()){
			System.out.println(coupon);
			categoryService.saveCoupon(coupon);
			
			//return new ModelAndView("redirect:accout");
		}
		
		else
		{
			return new ModelAndView("HomePage");
		}
			
			return new ModelAndView("redirect:HomePage");
	
	}

	
	
	
	//**************************************************************************




@RequestMapping(value={"/Uploade","/updateCoupon"},method=RequestMethod.GET)
public String showDetails(Map<String, Object> map,
		
		@Valid @ModelAttribute("Images_Electronics") Images_Electronics Images_Electronics, BindingResult result){
 
	//List<Coupon> coupons= couponService.getAllCoupons();
	//map.put("cous",coupons);
	//map.put("couSearch",searchCoupon);
	System.out.println(Images_Electronics);
	/*if(result.hasErrors()){
		//System.out.println("Search Object:" + searchEmployee);
		//System.out.println(result);
		return "coupon";
	}
	else{*/
		//searchCoupon=null;
	
		
		
		return "Uploade";
	
}



//*****************************************************************************************
//**** Save Coupon****/

	@RequestMapping(value="/saveImage",method=RequestMethod.POST)
	public ModelAndView saveAccount(@Valid @ModelAttribute("Images_Electronics") Images_Electronics Images_Electronics,
			BindingResult result)
	//public String addCoupon(@ModelAttribute("coupon") coupon coupon)
	{
		
		if(!result.hasErrors()){
			System.out.println(Images_Electronics);
			categoryService.saveImage(Images_Electronics);
			
			//return new ModelAndView("redirect:accout");
		}
		
		else
		{
			return new ModelAndView("HomePage");
		}
			
			return new ModelAndView("redirect:HomePage");
	
	}


//************************************************************************************
	
	
	
	//**************************************************************************




	@RequestMapping(value={"/Discount","/updateCoupon"},method=RequestMethod.GET)
	public String showDetails(Map<String, Object> map,
			
			@Valid @ModelAttribute("Discount") Discount Discount, BindingResult result){
	 
		//List<Coupon> coupons= couponService.getAllCoupons();
		//map.put("cous",coupons);
		//map.put("couSearch",searchCoupon);
		System.out.println(Discount);
		/*if(result.hasErrors()){
			//System.out.println("Search Object:" + searchEmployee);
			//System.out.println(result);
			return "coupon";
		}
		else{*/
			//searchCoupon=null;
		
			
			
			return "Discount";
		
	}



	//*****************************************************************************************
	//**** Save Coupon****/

		@RequestMapping(value="/saveDiscount",method=RequestMethod.POST)
		public ModelAndView saveAccount(@Valid @ModelAttribute("Discount") Discount Discount,
				BindingResult result)
		//public String addCoupon(@ModelAttribute("coupon") coupon coupon)
		{
			
			if(!result.hasErrors()){
				System.out.println(Discount);
				categoryService.saveDiscount(Discount);
				
				//return new ModelAndView("redirect:accout");
			}
			
			else
			{
				return new ModelAndView("HomePage");
			}
				
				return new ModelAndView("redirect:HomePage");
		
		}





}







	/*


	@RequestMapping(value="/subcategories",method=RequestMethod.GET,
			produces={"application/json"})
	public @ResponseBody List<sub_category> getAllSubCategories(@RequestParam("category_id")  Integer category_id)
{

		List<sub_category> sub_categories=categoryService.getAllSubCategories(category_id);
		System.out.println(sub_categories);
		return sub_categories;
}*/

	
	
	
	



