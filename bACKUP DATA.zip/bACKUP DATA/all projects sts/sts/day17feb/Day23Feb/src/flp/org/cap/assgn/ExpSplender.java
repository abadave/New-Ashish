package flp.org.cap.assgn;

public class ExpSplender {
	public static void main(String[] args) {
		
		
		int c,d;
		
		c=20;
		d=0;
		
		try
		{
			
			System.out.println(c/d);
			
		}
		catch(ArithmeticException ae )
		{
			
			
			System.out.println("Divide by Zero Exception");
		}

	}
	

}
