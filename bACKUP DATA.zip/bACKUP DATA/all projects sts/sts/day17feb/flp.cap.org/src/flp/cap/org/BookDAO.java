package flp.cap.org;

public interface BookDAO {
	
	public void savebook(Book book);
	public void  listofallbook();
	

}
