package org.capstore.controller;

import java.util.List;

import org.capstore.service.CategoryService;
import org.capstore.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

public class ProductController 
{

	
	@Autowired
	private ProductService service;
	
	
	
	@RequestMapping(value="/Furniture",method=RequestMethod.GET,
			produces={"application/json"})
	public  String getAllCategories()
{
		/*List<Category> categories=categoryService.getAllCategories();
		map.put("categories", categories);
		System.out.println(categories);*/
		return "Furniture";
}
	
	
	@RequestMapping("/Furniture")
	public String showPage2(){
		
		return "Furniture";
	}
	
	
	
	
	
	/*@RequestMapping(value="/Furniture",method=RequestMethod.GET,
			produces={"application/json"})
	
	public  @ResponseBody List<Object> getFurniture()
{
		List<Object> product=service.getAllFurniture();
		System.out.println(product);

		return product;
}*/
}
