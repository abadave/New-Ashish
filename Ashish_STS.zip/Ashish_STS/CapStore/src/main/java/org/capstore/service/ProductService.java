package org.capstore.service;

import java.util.List;

public interface ProductService 
{
	public List<Object> getAllFurniture();
}
