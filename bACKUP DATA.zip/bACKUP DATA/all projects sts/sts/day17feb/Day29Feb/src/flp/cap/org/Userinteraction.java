package flp.cap.org;
import java.util.Date;
import java.util.Scanner;


public class Userinteraction {
	
	public Account getAccountDetails()
	{
			Account auc=new Account();
			int acc_id;
			String acc_name;
			String open_date;
			String acc_type;
		    int opening_bal;
			
			Scanner sc=new Scanner(System.in);
			
			
			System.out.println("Enter account id");
			acc_id=sc.nextInt();
			System.out.println("Enter account holder name");
			acc_name=sc.next();
			System.out.println("Enter acc opening date");
			open_date=sc.next();
			System.out.println("Enter account type");
			acc_type=sc.next();
			System.out.println("Enter account balance");
			opening_bal=sc.nextInt();
			
			
			auc.setAcc_id(acc_id);
			auc.setAcc_name(acc_name);
			auc.setOpen_date(open_date);
			auc.setAcc_type(acc_type);
			auc.setOpening_bal(opening_bal);
			
			return auc;
			
		
	}
	
	
}
