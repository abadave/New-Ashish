package org.capstore.dao;

import java.util.List;
import java.util.Objects;

import javax.persistence.Query;


import org.capstore.domain.Category;
import org.capstore.domain.Discount;
import org.capstore.domain.Images_Electronics;
import org.capstore.domain.coupon;
import org.capstore.domain.images_furnitures;
import org.capstore.domain.product;
import org.capstore.domain.sub_category;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.classic.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class CategoryDaoImpl implements CategoryDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	
	@Transactional
	public List<Category> getAllCategories() {
		
		
		return sessionFactory.getCurrentSession().createQuery("from Category").list();

	}
	@Transactional
	public void saveCategory(Category category) {
		sessionFactory.getCurrentSession().save(category);

		
	}
	
	
	@Transactional
	public List<sub_category> getAllSubCategories(Integer category_id) {
		//System.out.println(sessionFactory.getCurrentSession().get(sub_category.class, category_id));
		
		//return sessionFactory.getCurrentSession().get(sub_category.class, category_id);
		
		return sessionFactory.getCurrentSession().createQuery("select sub_category_name from sub_category where category_id="+category_id).list();
		
	}
	
	
	@Transactional
	public List<sub_category> getsubcategory1() 
	{
		
		
		return sessionFactory.getCurrentSession().createQuery("select sub_category_name from sub_category where category_id=1").list();

	}
	
	@Transactional
	public List<product> getAllFurniture()
	{
		
		
//		product product;
		List<product> listResult =  sessionFactory.getCurrentSession().createQuery(" from product where category_id_FK=3").list();
		 
		 System.out.println(listResult);
		 System.out.println("inside");
			
		
		return listResult;
	}
	
	@Transactional
	public List<product> getAllKitchen()
	{
		List<product> listResult =  sessionFactory.getCurrentSession().createQuery(" from product where category_id_FK=2").list();
		 
		 System.out.println(listResult);
		 System.out.println("inside");
			
		
		return listResult;
		
		
	}
	
	@Transactional
	public List<product> getAllHome(){
		
		
		List<product> listResult =  sessionFactory.getCurrentSession().createQuery(" from product where category_id_FK=1").list();
		 
		 System.out.println(listResult);
		 System.out.println("inside");
			
		
		return listResult;
		
	}

	@Transactional
	public List<product> getmostVisitedFurniture(){
		
		    
		
		List<product> listResult =  sessionFactory.getCurrentSession().createQuery("from product  where category_id_FK=3 order by no_of_visited desc").list();
		
		
		 
		 System.out.println("Most viewed"+listResult);
		
		
		
	     return listResult;
		
	}

	// Ascending Price
	
	@Transactional
	public List<product> getAscendingPrice(){
		
		    
		
		List<product> listResult =  sessionFactory.getCurrentSession().createQuery("from product  where category_id_FK=3 order by price ").list();
		
		
		 
		 System.out.println("Ascending"+listResult);
		
		
		
	     return listResult;
		
	}
	
	// Descending Price
	
		@Transactional
		public List<product> getDescendingPrice(){
			
			    
			
			List<product> listResult =  sessionFactory.getCurrentSession().createQuery("from product  where category_id_FK=3 order by price desc ").list();
			
			
			 
			 System.out.println("Descending"+listResult);
			
			
			
		     return listResult;
			
		}

		// Rating
		
		@Transactional
		public List<product> getRating(){
			
			    
			
			List<product> listResult =  sessionFactory.getCurrentSession().createQuery("from product  where category_id_FK=3 order by rating desc ").list();
			
			
			 
			 System.out.println("Rating"+listResult);
			
			
			
		     return listResult;
			
		}
		
		// Generate Coupon
		
				@Transactional
				public List<product> getCoupon(){
					
					    
					
					List<product> listResult =  sessionFactory.getCurrentSession().createQuery("from coupon  ").list();
					
					
					 
					 System.out.println("Coupon"+listResult);
					
					
					
				     return listResult;
					
				}
				
				
				//***********************************************/
				
				
				
				@Transactional
				public void saveCoupon(coupon coupon) 
				{
					sessionFactory.getCurrentSession().save(coupon);
					
				}
				
				
				
			//*****************************************************/
				@Transactional
				public void saveImage(Images_Electronics Images_Electronics )
				{
					
					sessionFactory.getCurrentSession().save(Images_Electronics);
					
				}
	

				
				//********************************************
				@Transactional
				public void  saveDiscount(Discount discount)
				{
					
					
					sessionFactory.getCurrentSession().save(discount);
					
				}
}
