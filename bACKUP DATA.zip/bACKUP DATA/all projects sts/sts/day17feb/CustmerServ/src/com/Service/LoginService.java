package com.Service;

import com.pojo.Customer;
//import com.pojo;
import com.pojo.LoginUser;

public interface LoginService {
	
	public boolean isValidLogin(LoginUser loginUser);
	public void saveCustomer(Customer customer);

}
