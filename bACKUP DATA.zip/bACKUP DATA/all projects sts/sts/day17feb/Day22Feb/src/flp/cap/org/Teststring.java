package flp.cap.org;

public class Teststring {

	public static void main(String[] args) {

		String mystr="Ashish, Ajit Badave";
	String [] str=mystr.split(mystr);
	
	StringTokenizer tokenizer=new StringTokenizer (mystr,",");
	
	System.out.println(tokenizer.countTokens());
	
	}

}
