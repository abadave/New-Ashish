package flp.cap.org;

public class Myclass<T extends InterA> {
	private T obj;	
	
	public Myclass(T obj){
		this.obj=obj;
	}
	
	public void printClass(){
		System.out.println(obj.getClass().getName());
		obj.show();
	}

}
