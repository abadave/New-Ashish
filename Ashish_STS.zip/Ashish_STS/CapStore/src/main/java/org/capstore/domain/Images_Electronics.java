package org.capstore.domain;

import java.sql.Blob;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Images_Electronics

{
   @Id
   int image_id;
   String image_front_view;
   String image_side_view;
   String image_back_view;
   
  
   int  product_id;
   
   Images_Electronics(){}

public int getImage_id() {
	return image_id;
}

public void setImage_id(int image_id) {
	this.image_id = image_id;
}

public String getImage_front_view() {
	return image_front_view;
}

public void setImage_front_view(String image_front_view) {
	this.image_front_view = image_front_view;
}

public String getImage_side_view() {
	return image_side_view;
}

public void setImage_side_view(String image_side_view) {
	this.image_side_view = image_side_view;
}

public String getImage_back_view() {
	return image_back_view;
}

public void setImage_back_view(String image_back_view) {
	this.image_back_view = image_back_view;
}

public int getProduct_id() {
	return product_id;
}

public void setProduct_id(int product_id) {
	this.product_id = product_id;
}

public Images_Electronics(int image_id, String image_front_view, String image_side_view, String image_back_view,
		int product_id) {
	super();
	this.image_id = image_id;
	this.image_front_view = image_front_view;
	this.image_side_view = image_side_view;
	this.image_back_view = image_back_view;
	this.product_id = product_id;
}

@Override
public String toString() {
	return "Images_Electronics [image_id=" + image_id + ", image_front_view=" + image_front_view + ", image_side_view="
			+ image_side_view + ", image_back_view=" + image_back_view + ", product_id=" + product_id + "]";
}


}
