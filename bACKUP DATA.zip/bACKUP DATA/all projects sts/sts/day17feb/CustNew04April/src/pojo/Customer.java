package pojo;


import java.util.Date;

public class Customer {
	
	private int cusId;
	private String firstName;
	private String lastName;
	private String address;
	private String gender;
	private String cusType;
	private Date regDate;
	private double regFees;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(int cusId, String firstName, String lastName, String address, String gender, String cusType,
			Date regDate, double regFees) {
		super();
		this.cusId = cusId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.gender = gender;
		this.cusType = cusType;
		this.regDate = regDate;
		this.regFees = regFees;
	}
	public int getCusId() {
		return cusId;
	}
	public void setCusId(int cusId) {
		this.cusId = cusId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCusType() {
		return cusType;
	}
	public void setCusType(String cusType) {
		this.cusType = cusType;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	public double getRegFees() {
		return regFees;
	}
	public void setRegFees(double regFees) {
		this.regFees = regFees;
	}
	@Override
	public String toString() {
		return "Customer [cusId=" + cusId + ", firstName=" + firstName + ", lastName=" + lastName + ", address="
				+ address + ", gender=" + gender + ", cusType=" + cusType + ", regDate=" + regDate + ", regFees="
				+ regFees + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
}
