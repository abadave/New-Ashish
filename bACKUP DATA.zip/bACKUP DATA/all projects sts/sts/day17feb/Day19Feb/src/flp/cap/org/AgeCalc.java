package flp.cap.org;
import java.util.Scanner;
import java.util.Date;
import java.util.Calendar;

public class AgeCalc {
	String dob;
	
	
	Scanner sc=new Scanner (System.in);
	
	public void getdob(){
		
		System.out.println("Enter DOB-");
		dob=sc.next();		
	

	Date date1= new Date(dob);
	System.out.println(date1);
	
	Date date2= new Date();
	
	int year1 =date2.getYear();
	int year2 =date1.getYear();
	
	int diffyear= year1-year2;
	
	System.out.println(diffyear);
	
	}
}
}