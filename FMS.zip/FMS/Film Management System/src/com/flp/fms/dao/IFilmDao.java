package com.flp.fms.dao;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;


public interface IFilmDao {
	// method for language
	public List<Language> getLanguages();
	
	// method for category
    public List <Category> getCategory();

    // method for add film
    public void addFilm(Film film);

    // method to get all film details
    public Map<Integer, Film> getAllFilms();
    
    //method to search film
    public Map<Integer, Film> searchfilm();
    
    // method for remove film
    public Map<Integer, Film> removefilm();

    // method for update film
	public void updateFilm(Film film1);

	// method for search film using film1 object
	public Film searchFilm(int filmId1);
	
	
	
}



