package com.controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Service.LoginService;
import com.Service.LoginServiceImpl;
import com.pojo.Customer;


public class SaveCustomerServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
LoginService loginService=new LoginServiceImpl();
		
		Customer customer=new Customer();
		
		customer.setFirstName(request.getParameter("fname"));
		customer.setLastName(request.getParameter("lname"));
		customer.setAddress(request.getParameter("address"));
		customer.setGender(request.getParameter("gender"));
		
		String dob=request.getParameter("regDate");
		Date regDate=new Date(dob);
		customer.setRegDate(regDate);
	
		double regFees=Double.parseDouble(request.getParameter("fees"));
		customer.setRegFees(regFees);
		
		
		
		String custType=request.getParameter("Type");
		customer.setCusType(custType);
		
		System.out.println(customer);
		
		//Persist employee Object into DataBase
		loginService.saveCustomer(customer);
		
		//response.sendRedirect("SaveEmployeeServlet");
		request.getRequestDispatcher("pages/Customer.html").forward(request, response);
		
		
		
		
		
		
		
	}

}
