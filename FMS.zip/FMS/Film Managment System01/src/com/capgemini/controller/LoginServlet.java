package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.LoginUser;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
PrintWriter out=response.getWriter();
    	
        // validation for login
    	String userName=request.getParameter("user");
		String userPwd=request.getParameter("pass");
		
		LoginUser loginUser=new LoginUser();
		loginUser.setUserName(userName);
		loginUser.setUserPwd(userPwd);
		
		
		IFilmService loginService=new FilmServiceImpl();
		
		
		
		if(loginService.isValidLogin(loginUser))
			//response.sendRedirect("pages/success.html");
			request.getRequestDispatcher("pages/MenuSelection.html").forward(request, response);
		else
			response.sendRedirect("pages/index.html");
		
	}
}