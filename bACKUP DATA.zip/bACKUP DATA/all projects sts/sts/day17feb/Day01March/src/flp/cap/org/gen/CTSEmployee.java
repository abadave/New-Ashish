package flp.cap.org.gen;

public class CTSEmployee extends Employee {

	public CTSEmployee(String ename,double salary){
		super(ename,salary);
	}

}
