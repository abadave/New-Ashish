package org.capstore.domain;



import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class product {
	@Id
	@GeneratedValue
	private int product_id;
	private String product_name;
	

	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="category_id_FK")
	
	private Category category;
	
	private double price;
	private int no_of_visited;
    private String image;
    private int rating;
	
	public product(){}

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getNo_of_visited() {
		return no_of_visited;
	}

	public void setNo_of_visited(int no_of_visited) {
		this.no_of_visited = no_of_visited;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public product(int product_id, String product_name, Category category, double price, int no_of_visited,
			String image, int rating) {
		super();
		this.product_id = product_id;
		this.product_name = product_name;
		this.category = category;
		this.price = price;
		this.no_of_visited = no_of_visited;
		this.image = image;
		this.rating = rating;
	}

	@Override
	public String toString() {
		return "product [product_id=" + product_id + ", product_name=" + product_name + ", category=" + category
				+ ", price=" + price + ", no_of_visited=" + no_of_visited + ", image=" + image + ", rating=" + rating
				+ "]";
	}

	
	
}

	

	
	
	