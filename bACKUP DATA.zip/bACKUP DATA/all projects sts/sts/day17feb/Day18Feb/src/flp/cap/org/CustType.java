package flp.cap.org;

public enum CustType {

	SILVER(0,100), GOLD(101,300),  DIAMOND(301,500), PLATINUM(501,1000);
int minvalue,maxvalue;

CustType(int minvalue, int maxvalue){
	
	this.minvalue=minvalue;
	this.maxvalue=maxvalue;
	
}


}
