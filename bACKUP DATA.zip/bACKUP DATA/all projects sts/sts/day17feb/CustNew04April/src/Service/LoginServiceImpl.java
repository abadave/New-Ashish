package Service;

import dao.LoginDao;
import dao.LoginDaoImpl;
import pojo.Customer;
import pojo.LoginUser;

public class LoginServiceImpl implements LoginService {
	
	
	private LoginDao loginDao=new LoginDaoImpl();

	@Override
	public boolean isValidLogin(LoginUser loginUser) {
		
		/*boolean flag=false;
		
		if(loginUser.getUserName().equals("tom") && 
				loginUser.getUserPwd().equals("12345"))
			flag=true;
		*/
		return loginDao.isValidLogin(loginUser);
	}

	@Override
	public void saveCustomer(Customer customer) {
		loginDao.saveCustomer(customer);
	}

}

