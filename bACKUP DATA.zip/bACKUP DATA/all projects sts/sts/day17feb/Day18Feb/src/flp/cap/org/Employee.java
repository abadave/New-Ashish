package flp.cap.org;

public class Employee {

	int emp_id;
	String emp_name;
	Weekdays holiday=Weekdays.SAT;
	public void  getprint(){
		System.out.println(emp_id+ emp_name + holiday);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	}

}
