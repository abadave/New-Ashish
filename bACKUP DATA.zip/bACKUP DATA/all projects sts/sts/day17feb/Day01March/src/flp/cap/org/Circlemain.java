package flp.cap.org;

public class Circlemain {

	public static void main (String[] args){
		
		Circle<Integer> crl=new Circle<Integer>(10);
		
		crl.getshow();
	}
}
