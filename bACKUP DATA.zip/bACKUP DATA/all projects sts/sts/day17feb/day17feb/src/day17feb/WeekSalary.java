package day17feb;
import java.util.Scanner;
public class WeekSalary extends Employee {

	float no_hours, wagesper_hour;
	double salary;
	
	public double Calculatesalary()
	{
		System.out.println("Enter the no of hours");
		Scanner s1=new Scanner(System.in);
		no_hours= s1.nextFloat();
		
		System.out.println("Enter the wages per hour");
		Scanner s2=new Scanner(System.in);
		wagesper_hour= s1.nextFloat();
		
		salary=no_hours*wagesper_hour;
		System.out.println(" The Salary-->" + salary);
	}
	
	

}
