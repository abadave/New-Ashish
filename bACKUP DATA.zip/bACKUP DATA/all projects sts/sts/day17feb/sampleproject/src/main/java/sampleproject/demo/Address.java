package sampleproject.demo;

public class Address {
	
	private int addId;
	private int doorno;
	private String streetname;
	private String city;
	private String state;
	
	public Address(){}
	
	public Address(int addId, int doorno, String streetname, String city, String state) {
		super();
		this.addId = addId;
		this.doorno = doorno;
		this.streetname = streetname;
		this.city = city;
		this.state = state;
	}

	public int getAddId() {
		return addId;
	}

	public void setAddId(int addId) {
		this.addId = addId;
	}

	public int getDoorno() {
		return doorno;
	}

	public void setDoorno(int doorno) {
		this.doorno = doorno;
	}

	public String getStreetname() {
		return streetname;
	}

	public void setStreetname(String streetname) {
		this.streetname = streetname;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "Address [addId=" + addId + ", doorno=" + doorno + ", streetname=" + streetname + ", city=" + city
				+ ", state=" + state + "]";
	}
	
}
