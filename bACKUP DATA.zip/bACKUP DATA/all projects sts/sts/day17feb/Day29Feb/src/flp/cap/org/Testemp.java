package flp.cap.org;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Testemp {

	public static void main(String[] args) {
		
		HashSet<Employee> set=new HashSet<>();
		set.add(new Employee(101, "Ashish", "Badave", 17500));
		set.add(new Employee(102, "Akash", "Badave", 17500));
		set.add(new Employee(103, "Ashish", "Kulkarni", 14500));
		set.add(new Employee(104, "Ashish", "Badave", 17500));
		set.add(new Employee(101, "Ashish", "Badave", 17500));
		set.add(new Employee(105, "Ashish", "Kulkarni", 17500));
		set.add(new Employee(106, "Ravi", "Sole", 17500));
		set.add(new Employee(107, "Rupesh", "Jadhav", 19500));
		set.add(new Employee(108, "Akshay", "Sagare", 18500));

		Iterator<Employee> itr=set.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		
	}

}
