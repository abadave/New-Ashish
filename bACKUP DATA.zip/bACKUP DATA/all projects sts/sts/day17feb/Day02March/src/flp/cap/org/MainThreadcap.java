package flp.cap.org;

public class MainThreadcap {

	public static void main(String[] args) {
	
		
		ThreadCap t1=new ThreadCap("Capgemini");
		ThreadCap t2=new ThreadCap("Welcome");
		
        t1.start();
        t2.start();	
	}

}
