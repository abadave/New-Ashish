package flp.cap.org;
import java.util.Comparator;

	public class Salarysort  implements Comparator<EmployeeLinkHash>{

		@Override
		public int compare(EmployeeLinkHash asd1, EmployeeLinkHash asd2) {
			
			if(asd1.getSalary()>asd2.getSalary())
				return 1;
			else if(asd1.getSalary()<asd2.getSalary())
				return -1;
			else
				return 0;
		}


}
