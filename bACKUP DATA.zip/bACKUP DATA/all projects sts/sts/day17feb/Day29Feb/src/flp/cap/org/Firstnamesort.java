package flp.cap.org;
import java.util.Comparator;

public class Firstnamesort implements Comparator<EmployeeLinkHash>{

	public int compare(EmployeeLinkHash asd1, EmployeeLinkHash asd2) {
		
		if(asd1.getFirstname().compareTo(asd2.getFirstname())>0)
			return 1;
		else if(asd1.getFirstname().compareTo(asd2.getFirstname())>0)
			return -1;
		else
			return 0;
	}


	
}
