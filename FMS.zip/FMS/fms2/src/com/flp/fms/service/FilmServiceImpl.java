package com.flp.fms.service;
import java.util.List;

import com.flp.fms.dao.FilmDaoImplForDB;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import java.util.Map;
import java.util.Set;
import com.flp.fms.domain.Film;


public class FilmServiceImpl implements IFilmService{
	
	private IFilmDao filmDao=new FilmDaoImplForDB();

	@Override
	public List<Language> getLanguages() {
		
		return filmDao.getLanguages();
	}

    public List<Category> getCategory() {
		
		return filmDao.getCategory();
}
    @Override
    public void addFilm(Film film) {

	filmDao.addFilm(film);	
}

	

	
	@Override
	public List<Film> getAllFilm() {
		// TODO Auto-generated method stub
		return filmDao.getAllFilm();
	}

	
		//RETRIEVING FILM FROM FILM REPOSITORY USING FILM ID
		@Override
		public Film searchFilm(int filmId) {
				
			return filmDao.searchFilm(filmId);
		}
		
		//RETRIEVING FILM FROM FILM REPOSITORY USING LANGUAGE
		@Override
		public List<Film> searchFilm(Language language) {
			
			return filmDao.searchFilm(language);
		}
		
		//RETRIEVING FILM FROM FILM REPOSITORY USING FILM TITLE
		@Override
		public Film searchFilm(String title) {
			
			return filmDao.searchFilm(title);
		}
		
		
		//RETRIEVING FILM FROM FILM REPOSITORY USING FILM RATING
		@Override
		public List<Film> searchFilmByRating(int rating) {
			
			return filmDao.searchFilmByRating(rating);
		}
		
		
		//RETRIEVING FILM FROM FILM REPOSITORY USING ACTOR
		@Override
		public List<Film> searchFilm(Actor actor) {
			
			return filmDao.searchFilm(actor);
		}
		
		

		
		//REMOVING FILM USING FILM ID
		@Override
		public void removeFilm(int filmId) {
			
			filmDao.removeFilm(filmId);
		}

		//REMOVING FILM USING FILM TITLE
		@Override
		public void removeFilm(String title) {
			
			filmDao.removeFilm(title);
		}

		//REMOVING FILM USING RATING
		@Override
		public void removeFilmByRating(int rating) {
			
			filmDao.removeFilmByRating(rating);
		}

		@Override
		public void removeFilm(Actor actor) {
			
			filmDao.removeFilm(actor);
		}

		@Override
		public void updateFilm(Film film) {

			filmDao.updateFilm(film);	
		}
		
	}

	
	
	
	
	
	

