package com.dao;


import com.pojo.Customer;
import com.pojo.LoginUser;

public interface LoginDao {
	
	public boolean isValidLogin(LoginUser loginUser) ;
	public void saveCustomer(Customer customer);

}
