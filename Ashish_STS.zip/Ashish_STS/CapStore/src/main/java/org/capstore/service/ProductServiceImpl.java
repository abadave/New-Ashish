package org.capstore.service;

import java.util.List;

import org.capstore.dao.ProductDaoImpl;

public class ProductServiceImpl

{   ProductDaoImpl dao = new ProductDaoImpl();


	public List<Object> getAllFurniture()
	{
		
		
		return dao.getAllFurniture();
	}
}
